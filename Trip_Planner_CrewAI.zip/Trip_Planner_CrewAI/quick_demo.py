"""
Quick demo: calls OpenAI once per agent (simulating all 11 agents),
collects results, and generates the PDF. Finishes in ~60 seconds.
"""
import os, sys, json
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

from dotenv import load_dotenv
load_dotenv()

from openai import OpenAI
from pdf_generator import generate_trip_pdf
from memory_manager import TripMemoryManager
from datetime import datetime

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
memory = TripMemoryManager()

TRIP = {
    "source": "Bangalore", "destination": "Goa",
    "start_date": "2025-06-01", "end_date": "2025-06-05",
    "budget": 200000, "travelers": 2, "travel_type": "couple",
    "hotel_preference": "beach resort", "food_preference": "non-veg",
    "transport_preference": "flight",
    "interests": ["beach", "nightlife", "sightseeing", "seafood"],
    "luxury_vs_budget": "budget",
}


def ask(system_prompt: str, user_prompt: str) -> str:
    resp = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "system", "content": system_prompt},
                  {"role": "user", "content": user_prompt}],
        temperature=0.4,
    )
    return resp.choices[0].message.content.strip()


def run_agent(name: str, system: str, prompt: str) -> str:
    print(f"  [{name}] Running...")
    result = ask(system, prompt)
    print(f"  [{name}] Done.")
    return result


print("\n" + "="*60)
print("  TRIP PLANNER - QUICK DEMO (11 Agents Simulated)")
print("="*60)
print(f"  {TRIP['source']} -> {TRIP['destination']}  |  Rs{TRIP['budget']:,}")
print("="*60 + "\n")

# ── Agent 1: Orchestrator (planning phase) ────────────────────────
print("[Orchestrator] Analysing trip & planning agent execution order...")
orchestrator_plan = run_agent(
    "Orchestrator",
    "You are the Trip Planning Orchestrator. Analyse the trip request and decide the execution plan.",
    f"Trip: {json.dumps(TRIP, indent=2)}\n\nCreate an execution plan listing which agents "
    "should run and in what order to produce the best trip plan."
)

# ── Agent 2: Memory Agent ─────────────────────────────────────────
memory_data = memory.format_preferences_for_agent("user_001")
print(f"[Memory Agent] Loaded: {memory_data[:80]}...")

# ── Agent 3: Weather Agent ────────────────────────────────────────
weather_result = run_agent(
    "Weather Agent",
    "You are a weather specialist. Provide a realistic 5-day weather forecast in JSON.",
    f"Provide weather forecast for {TRIP['destination']} from {TRIP['start_date']} to "
    f"{TRIP['end_date']}. Return JSON with: city, forecast (list of 5 days with date/temp/description/humidity), "
    "recommendation (string with packing advice)."
)

# ── Agent 4: Transport Agent ──────────────────────────────────────
transport_result = run_agent(
    "Transport Agent",
    "You are a transport & logistics expert. Return realistic options in JSON.",
    f"Find transport from {TRIP['source']} to {TRIP['destination']} for {TRIP['travelers']} travelers "
    f"on {TRIP['start_date']}. Preference: {TRIP['transport_preference']}. Budget: Rs{TRIP['budget']*0.3:.0f}. "
    "Return JSON with: route, options (list with mode/duration/cost_per_person/total_cost/airlines/booking_note), recommendation."
)

# ── Agent 5: Hotel Agent ──────────────────────────────────────────
hotel_result = run_agent(
    "Hotel Agent",
    "You are a hospitality expert. Return hotel options in JSON.",
    f"Find hotels in {TRIP['destination']} for {TRIP['travelers']} travelers, "
    f"{TRIP['start_date']} to {TRIP['end_date']}. Budget: Rs{TRIP['budget']*0.35/4:.0f}/night. "
    f"Preference: {TRIP['hotel_preference']}. "
    "Return JSON with: city, nights, hotels (list with name/stars/rating/price_per_night/total_cost/amenities/location/booking), recommendation."
)

# ── Agent 6: Places Agent ─────────────────────────────────────────
places_result = run_agent(
    "Places Agent",
    "You are a destination & food expert. Return attractions and food spots in JSON.",
    f"Top attractions and food in {TRIP['destination']} for interests: {', '.join(TRIP['interests'])}. "
    "Return JSON with: city, attractions (list with name/type/timing/entry/highlight), "
    "local_tips (list of 5 practical tips)."
)

# ── Agent 7: Budget Agent ─────────────────────────────────────────
budget_result = run_agent(
    "Budget Agent",
    "You are a travel budget optimizer. Return a detailed budget breakdown in JSON.",
    f"Budget: Rs{TRIP['budget']}, travelers: {TRIP['travelers']}, days: 5, "
    f"hotel preference: {TRIP['hotel_preference']}, transport: {TRIP['transport_preference']}. "
    "Return JSON with: total_budget, breakdown (intercity_transport/accommodation/food_and_dining/"
    "activities/local_transport/miscellaneous), total_allocated, savings_buffer, budget_status, "
    "per_person_budget, optimization_tips (list of 5 tips)."
)

# ── Agent 8: Itinerary Agent ──────────────────────────────────────
itinerary_result = run_agent(
    "Itinerary Agent",
    "You are a master itinerary planner. Return a detailed day-wise plan in JSON.",
    f"Create a 5-day itinerary for {TRIP['destination']} ({TRIP['travel_type']} trip). "
    f"Interests: {', '.join(TRIP['interests'])}. Food: {TRIP['food_preference']}. "
    f"Start: {TRIP['start_date']}. End: {TRIP['end_date']}. "
    "Day 1 = arrival, Day 5 = departure. "
    "Return JSON with: trip_title, days (list with day/date/theme/morning/afternoon/evening/"
    "meals dict with breakfast+lunch+dinner/estimated_daily_cost)."
)

# ── Agent 9: Final Review Agent ───────────────────────────────────
review_result = run_agent(
    "Review Agent",
    "You are a QA specialist for travel plans. Validate everything.",
    f"Review this trip plan:\nBudget result: {budget_result[:300]}\n"
    f"Hotel result: {hotel_result[:300]}\nItinerary: {itinerary_result[:300]}\n\n"
    "Check: budget compliance, date alignment, completeness. "
    "Return JSON: overall_status ('APPROVED' or 'NEEDS_REVISION'), checks, approval_message."
)

# ── Agent 10: Memory Update ───────────────────────────────────────
print("  [Memory Agent] Saving preferences...")
memory.save_preferences("user_001", {
    "preferred_hotel": TRIP["hotel_preference"],
    "preferred_food": TRIP["food_preference"],
    "preferred_transport": TRIP["transport_preference"],
    "last_destination": TRIP["destination"],
    "travel_type": TRIP["travel_type"],
})
memory.save_trip("user_001", {
    "destination": TRIP["destination"],
    "source": TRIP["source"],
    "start_date": TRIP["start_date"],
    "budget": TRIP["budget"],
})
print("  [Memory Agent] Preferences saved.")

# ── Agent 11: PDF Generator ───────────────────────────────────────
print("\n[Orchestrator] All agents complete. Approving PDF generation...")

def safe_json(text: str) -> dict:
    import re
    # Try to extract JSON from markdown code fences
    match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', text, re.DOTALL)
    if match:
        try: return json.loads(match.group(1))
        except: pass
    # Try raw JSON
    match = re.search(r'\{.*\}', text, re.DOTALL)
    if match:
        try: return json.loads(match.group(0))
        except: pass
    return {"raw": text}

print("[PDF Agent] Building report...")
trip_data_for_pdf = {
    **TRIP,
    "weather_data": safe_json(weather_result),
    "transport_data": safe_json(transport_result),
    "hotel_data": safe_json(hotel_result),
    "places_data": safe_json(places_result),
    "budget_summary": safe_json(budget_result),
    "itinerary": safe_json(itinerary_result),
}

ts = datetime.now().strftime("%Y%m%d_%H%M%S")
pdf_path = generate_trip_pdf(trip_data_for_pdf, f"TripPlan_Goa_{ts}.pdf")

print("\n" + "="*60)
print("  TRIP PLANNING COMPLETE!")
print("="*60)
print(f"  Destination : {TRIP['destination']}")
print(f"  PDF Report  : {pdf_path}")
print(f"  Review      : {safe_json(review_result).get('overall_status', 'APPROVED')}")
print("="*60)
print("\nOpen the PDF file to view your complete trip plan!")
