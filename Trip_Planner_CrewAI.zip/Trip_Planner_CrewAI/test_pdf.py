"""
Standalone test: generates a sample PDF without requiring an OpenAI API key.
Run: python test_pdf.py
"""
import sys
sys.path.insert(0, ".")

from pdf_generator import generate_trip_pdf

sample_trip = {
    "source": "Bangalore",
    "destination": "Goa",
    "start_date": "2025-06-01",
    "end_date": "2025-06-05",
    "budget": 30000,
    "travelers": 2,
    "travel_type": "couple",
    "hotel_preference": "beach resort",
    "food_preference": "non-veg",
    "transport_preference": "flight",
    "weather_data": {
        "city": "Goa",
        "forecast": [
            {"date": "Jun 01", "temp": "30°C", "description": "Partly cloudy", "humidity": "70%"},
            {"date": "Jun 02", "temp": "32°C", "description": "Sunny", "humidity": "65%"},
            {"date": "Jun 03", "temp": "29°C", "description": "Light rain morning", "humidity": "80%"},
            {"date": "Jun 04", "temp": "31°C", "description": "Clear sky", "humidity": "68%"},
            {"date": "Jun 05", "temp": "33°C", "description": "Sunny and hot", "humidity": "62%"},
        ],
        "recommendation": (
            "Weather in Goa is mostly pleasant. Pack light cotton clothes, sunscreen, "
            "and an umbrella for occasional showers. Mornings are ideal for outdoor sightseeing."
        ),
    },
    "transport_data": {
        "route": "Bangalore → Goa",
        "travel_date": "2025-06-01",
        "travelers": 2,
        "options": [
            {
                "mode": "Flight (Recommended)",
                "duration": "1h 15m",
                "cost_per_person": 4500,
                "total_cost": 9000,
                "airlines": "IndiGo 6E-123 (07:30) | Air India AI-456 (14:00)",
                "booking_note": "Book 2-3 weeks in advance for best fares.",
            },
            {
                "mode": "Train",
                "duration": "10h 30m (overnight)",
                "cost_per_person": 1200,
                "total_cost": 2400,
                "trains": "Goa Express 10103 (21:45)",
                "booking_note": "Book via IRCTC. Tatkal quota available.",
            },
        ],
        "recommendation": "Flight recommended for a couple trip — saves travel day.",
    },
    "hotel_data": {
        "city": "Goa",
        "nights": 4,
        "travelers": 2,
        "hotels": [
            {
                "name": "Coconut Grove Beach Resort Goa",
                "stars": 4,
                "rating": 4.3,
                "price_per_night": 3500,
                "total_cost": 14000,
                "amenities": ["Private beach access", "Swimming pool", "Free WiFi", "Breakfast included", "Bar"],
                "location": "North Goa, 100m from Baga Beach",
                "booking": "MakeMyTrip / Goibibo",
            },
            {
                "name": "OYO Premium Goa Central",
                "stars": 3,
                "rating": 4.0,
                "price_per_night": 1800,
                "total_cost": 7200,
                "amenities": ["AC rooms", "Free WiFi", "Parking", "Room service"],
                "location": "Calangute, 5 min walk to beach",
                "booking": "OYO / Booking.com",
            },
        ],
        "recommendation": "Coconut Grove Beach Resort Goa",
        "booking_tip": "Book at least 2 weeks in advance during peak season.",
    },
    "places_data": {
        "city": "Goa",
        "total_attractions": 6,
        "attractions": [
            {"name": "Baga Beach", "type": "Beach", "timing": "6 AM – 10 PM", "entry": "Free", "highlight": "Water sports, shacks, vibrant nightlife"},
            {"name": "Calangute Beach", "type": "Beach", "timing": "Open all day", "entry": "Free", "highlight": "Largest beach, ideal for sunbathing"},
            {"name": "Basilica of Bom Jesus", "type": "Heritage", "timing": "9 AM – 6:30 PM", "entry": "Free", "highlight": "UNESCO World Heritage Site, 16th century"},
            {"name": "Aguada Fort", "type": "Fort", "timing": "9:30 AM – 6 PM", "entry": "Free", "highlight": "Portuguese fort with lighthouse, sea views"},
            {"name": "Tito's Club", "type": "Nightclub", "timing": "10 PM – 3 AM", "entry": "₹1000 couple", "highlight": "Legendary Goa nightclub since 1971"},
            {"name": "Fisherman's Wharf", "type": "Restaurant", "cuisine": "Goan Seafood", "avg_cost": "₹800/person", "timing": "12 PM – 11 PM"},
        ],
        "local_tips": [
            "Rent a scooter (₹300/day) for easy beach-hopping",
            "Try Goan fish curry rice at local shacks — more authentic than restaurants",
            "Avoid peak noon hours (12–3 PM) for outdoor sightseeing",
            "Carry cash — many beach shacks and small shops don't accept cards",
            "Wednesday Anjuna flea market is a must-visit for souvenirs",
        ],
    },
    "budget_summary": {
        "total_budget": 30000,
        "breakdown": {
            "intercity_transport": 9000,
            "accommodation": 14000,
            "food_and_dining": 4000,
            "activities_and_sightseeing": 1600,
            "local_transport": 2000,
            "miscellaneous": 1400,
        },
        "total_allocated": 32000,
        "savings_buffer": -2000,
        "budget_status": "Over Budget by ₹2,000 ✗",
        "per_person_budget": 15000,
        "optimization_tips": [
            "Book flights 3–4 weeks in advance for 20–30% savings (saves ~₹2,000)",
            "Switch to OYO Premium (₹1,800/night) instead of beach resort — saves ₹6,800",
            "Cook breakfast at hotel instead of restaurant for 2 days — saves ₹800",
            "Use local buses (₹20–50/trip) instead of taxis for short distances",
            "Avoid luxury beach clubs; free public beaches are equally beautiful",
        ],
    },
    "itinerary": {
        "trip_title": "Romantic 5-Day Goa Getaway — Bangalore to Goa",
        "days": [
            {
                "day": 1,
                "date": "2025-06-01 (Sunday)",
                "theme": "Arrival & Settle In",
                "morning": "IndiGo 6E-123 flight from Bangalore (07:30) → Arrive Goa Airport (08:45). "
                           "Collect luggage, take pre-booked cab to hotel.",
                "afternoon": "Hotel check-in (12:00 PM). Freshen up and relax. "
                              "Lunch at Fisherman's Wharf — try the Goan fish curry.",
                "evening": "Sunset walk at Calangute Beach. Dinner at a beach shack.",
                "meals": {
                    "breakfast": "Airport café / in-flight snack",
                    "lunch": "Fisherman's Wharf (₹800/person)",
                    "dinner": "Infantaria Beach Shack (₹600/person)",
                },
            },
            {
                "day": 2,
                "date": "2025-06-02 (Monday)",
                "theme": "North Goa Beaches & Water Sports",
                "morning": "Baga Beach water sports: jet ski, parasailing, banana boat (9 AM–12 PM). "
                           "Estimated cost: ₹1,500/person.",
                "afternoon": "Anjuna Beach walk and flea market browsing. "
                              "Lunch at Curlies Beach Shack.",
                "evening": "Sunset at Vagator Beach cliffs. "
                            "Night out at Tito's Club (10 PM).",
                "meals": {
                    "breakfast": "Hotel breakfast (included)",
                    "lunch": "Curlies Beach Shack (₹700/person)",
                    "dinner": "Pre-club dinner at Britto's Restaurant (₹900/person)",
                },
            },
            {
                "day": 3,
                "date": "2025-06-03 (Tuesday)",
                "theme": "Heritage & Culture (light rain expected — indoor-friendly)",
                "morning": "Visit Basilica of Bom Jesus (UNESCO) and Se Cathedral in Old Goa. "
                           "Guide tour recommended (₹200).",
                "afternoon": "Fontainhas Latin Quarter walk — colourful Portuguese houses. "
                              "Coffee at a local café.",
                "evening": "Panaji city market for souvenirs. "
                            "Candlelit dinner at Viva Panjim.",
                "meals": {
                    "breakfast": "Hotel breakfast (included)",
                    "lunch": "George Restaurant, Panaji (₹600/person)",
                    "dinner": "Viva Panjim (₹900/person)",
                },
            },
            {
                "day": 4,
                "date": "2025-06-04 (Wednesday)",
                "theme": "South Goa Day Trip — Pristine Beaches",
                "morning": "Rent scooters and head to South Goa. Colva Beach (9 AM). "
                           "Stop at Palolem Beach — most scenic beach in Goa.",
                "afternoon": "Lunch at Dropadi Restaurant, Palolem. "
                              "Cabo de Rama Fort visit (free entry, great views).",
                "evening": "Return to hotel. Spa session or pool time. "
                            "Final seafood dinner at Lucky Restaurant.",
                "meals": {
                    "breakfast": "Hotel breakfast (included)",
                    "lunch": "Dropadi Restaurant Palolem (₹700/person)",
                    "dinner": "Lucky Restaurant (₹1,000/person)",
                },
            },
            {
                "day": 5,
                "date": "2025-06-05 (Thursday)",
                "theme": "Departure Day",
                "morning": "Leisurely breakfast. Last-minute shopping at local market. "
                           "Hotel checkout by 11 AM.",
                "afternoon": "Cab to Goa Airport. Depart on return flight to Bangalore.",
                "evening": "Arrive Bangalore. Trip complete!",
                "meals": {
                    "breakfast": "Hotel breakfast (included)",
                    "lunch": "Airport food court",
                    "dinner": "Home / Bangalore restaurant",
                },
            },
        ],
    },
}

if __name__ == "__main__":
    print("Generating PDF trip plan...")
    path = generate_trip_pdf(sample_trip, "TripPlan_Goa_Sample.pdf")
    print(f"\nPDF created successfully: {path}")
    print("Open 'TripPlan_Goa_Sample.pdf' to view your trip plan!")
