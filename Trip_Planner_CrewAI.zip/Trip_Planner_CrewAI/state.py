from dataclasses import dataclass, field, asdict
from typing import Dict, Any, List
import json


@dataclass
class TripState:
    # User input
    user_id: str = "default_user"
    source: str = ""
    destination: str = ""
    start_date: str = ""
    end_date: str = ""
    budget: float = 0.0
    travelers: int = 1
    travel_type: str = "solo"
    hotel_preference: str = "mid-range"
    food_preference: str = "any"
    transport_preference: str = "any"
    interests: List[str] = field(default_factory=list)
    luxury_vs_budget: str = "budget"

    # Agent outputs
    weather_data: Dict[str, Any] = field(default_factory=dict)
    hotel_data: Dict[str, Any] = field(default_factory=dict)
    transport_data: Dict[str, Any] = field(default_factory=dict)
    places_data: Dict[str, Any] = field(default_factory=dict)
    budget_summary: Dict[str, Any] = field(default_factory=dict)
    itinerary: Dict[str, Any] = field(default_factory=dict)

    # Orchestrator control
    review_status: str = "pending"
    is_approved: bool = False
    retry_agents: List[str] = field(default_factory=list)
    orchestrator_notes: str = ""
    pdf_path: str = ""

    def to_dict(self) -> Dict:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2, default=str)

    @classmethod
    def from_dict(cls, data: Dict) -> "TripState":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})

    def trip_duration_days(self) -> int:
        from datetime import datetime
        try:
            start = datetime.strptime(self.start_date, "%Y-%m-%d")
            end = datetime.strptime(self.end_date, "%Y-%m-%d")
            return max(1, (end - start).days)
        except Exception:
            return 5

    def budget_per_person(self) -> float:
        return self.budget / max(1, self.travelers)

    def summary_string(self) -> str:
        return (
            f"{self.travelers} traveler(s), {self.travel_type} trip from {self.source} "
            f"to {self.destination} ({self.start_date} to {self.end_date}), "
            f"budget INR {self.budget:,.0f}, hotel: {self.hotel_preference}, "
            f"transport: {self.transport_preference}, food: {self.food_preference}, "
            f"interests: {', '.join(self.interests)}"
        )
