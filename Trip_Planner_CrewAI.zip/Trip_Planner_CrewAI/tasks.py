from crewai import Task
from state import TripState


def create_user_input_task(agent, state: TripState) -> Task:
    return Task(
        description=(
            f"Validate and structure the following trip requirements:\n"
            f"{state.summary_string()}\n\n"
            "Confirm all required fields are present: source, destination, dates, budget, "
            "traveler count, travel type, hotel/food/transport preferences, and interests. "
            "If any critical field is missing or ambiguous, note it clearly. "
            "Output a clean JSON summary of the validated trip requirements."
        ),
        expected_output=(
            "A structured JSON with all validated trip fields: source, destination, "
            "start_date, end_date, budget, travelers, travel_type, hotel_preference, "
            "food_preference, transport_preference, interests. "
            "Include a 'validation_status' field: 'ok' or 'missing_fields: [list]'."
        ),
        agent=agent,
    )


def create_memory_retrieval_task(agent, state: TripState) -> Task:
    return Task(
        description=(
            f"Load past trip preferences for user '{state.user_id}'. "
            f"Check if the user has previously expressed preferences for: "
            f"hotel type, food, transport mode, or specific destinations. "
            f"Identify any patterns that should influence the current trip plan for "
            f"{state.destination}. "
            "If this is a new user, note that explicitly."
        ),
        expected_output=(
            "A summary of the user's historical preferences (if any) and "
            "specific recommendations for the current trip based on past behaviour. "
            "Include: preferred_hotel_tier, preferred_food, preferred_transport, "
            "past_destinations, and personalisation_notes."
        ),
        agent=agent,
    )


def create_weather_task(agent, state: TripState) -> Task:
    return Task(
        description=(
            f"Fetch the weather forecast for {state.destination} "
            f"from {state.start_date} to {state.end_date}. "
            f"Use the tool with input: '{state.destination}|{state.start_date}|{state.end_date}'\n\n"
            "Analyse the forecast and:\n"
            "1. Identify any weather risks (heavy rain, extreme heat, storms)\n"
            "2. Recommend best times of day for outdoor activities\n"
            "3. Suggest appropriate clothing and packing items\n"
            "4. Flag if any days need itinerary adjustments due to weather"
        ),
        expected_output=(
            "A JSON weather report with: city, daily_forecast (list with date/temp/description/humidity), "
            "weather_risks (list), best_outdoor_times, packing_recommendations, "
            "and itinerary_impact (any day that needs adjustment)."
        ),
        agent=agent,
    )


def create_transport_task(agent, state: TripState) -> Task:
    travelers_str = str(state.travelers)
    return Task(
        description=(
            f"Research transport options from {state.source} to {state.destination} "
            f"for {state.travelers} traveler(s) on {state.start_date} "
            f"(return on {state.end_date}). "
            f"User preference: {state.transport_preference}. "
            f"Total budget available for transport: Rs{state.budget * 0.3:,.0f} (30% of total).\n\n"
            f"Use the tool with: '{state.source}|{state.destination}|{state.start_date}|"
            f"{travelers_str}|{state.transport_preference}'\n\n"
            "Provide options for onward + return journey. Include cost estimates, "
            "duration, and booking instructions."
        ),
        expected_output=(
            "A JSON transport plan with: route, options (list of flight/train/car with "
            "cost_per_person, total_cost, duration, booking_instructions), "
            "recommended_option, and total_transport_budget."
        ),
        agent=agent,
    )


def create_hotel_task(agent, state: TripState) -> Task:
    hotel_budget = state.budget * 0.35 / max(1, state.trip_duration_days() - 1)
    return Task(
        description=(
            f"Find hotels in {state.destination} for {state.travelers} traveler(s), "
            f"check-in {state.start_date}, check-out {state.end_date}. "
            f"Budget per night: Rs{hotel_budget:,.0f}. "
            f"Preference: {state.hotel_preference}. "
            f"Travel type: {state.travel_type}.\n\n"
            f"Use the tool with: '{state.destination}|{state.start_date}|{state.end_date}|"
            f"{state.travelers}|{hotel_budget:.0f}|{state.hotel_preference}'\n\n"
            "Provide top 3 hotel options with full details. "
            "Clearly flag if options exceed the per-night budget."
        ),
        expected_output=(
            "A JSON hotel report with: city, nights, top_3_hotels (each with name, stars, "
            "rating, price_per_night, total_cost, amenities, location, booking_platform), "
            "recommended_hotel, and budget_compliance (within/over)."
        ),
        agent=agent,
    )


def create_places_task(agent, state: TripState) -> Task:
    interests_str = ",".join(state.interests) if state.interests else "sightseeing,food,culture"
    return Task(
        description=(
            f"Discover tourist attractions and local experiences in {state.destination} "
            f"matching interests: {interests_str}. "
            f"Travel type: {state.travel_type}. Duration: {state.trip_duration_days()} days.\n\n"
            f"Use the tool with: '{state.destination}|{interests_str}'\n\n"
            "Cover: top attractions with timings & entry fees, "
            "local food recommendations matching '{state.food_preference}' preference, "
            "unique experiences, and insider tips."
        ),
        expected_output=(
            "A JSON places report with: attractions (list with name, type, timing, entry_fee, "
            "duration_needed, highlight), food_spots (list with name, cuisine, avg_cost), "
            "unique_experiences (list), local_tips (list), "
            "and total_activity_cost_estimate."
        ),
        agent=agent,
    )


def create_budget_task(agent, state: TripState) -> Task:
    return Task(
        description=(
            f"Calculate a detailed budget breakdown for the trip:\n"
            f"- Total budget: Rs{state.budget:,.0f}\n"
            f"- Travelers: {state.travelers}\n"
            f"- Days: {state.trip_duration_days()}\n"
            f"- Transport preference: {state.transport_preference}\n"
            f"- Hotel preference: {state.hotel_preference}\n"
            f"- Luxury vs budget: {state.luxury_vs_budget}\n\n"
            "Use the tool to calculate. Estimate transport at 30% of budget, "
            f"hotel at 35%, food at 20%, activities at 10%, miscellaneous at 5%.\n\n"
            f"Tool input: '{state.budget}|{state.travelers}|{state.trip_duration_days()}|"
            f"{state.budget * 0.30:.0f}|{state.budget * 0.35 / max(1, state.trip_duration_days()-1):.0f}|"
            f"{state.hotel_preference}'"
        ),
        expected_output=(
            "A JSON budget report with: total_budget, breakdown (by category), "
            "total_allocated, savings_buffer, budget_status (within/over), "
            "per_person_budget, and 5+ optimization_tips."
        ),
        agent=agent,
    )


def create_itinerary_task(agent, state: TripState) -> Task:
    return Task(
        description=(
            f"Create a detailed day-by-day itinerary for a {state.trip_duration_days()}-day trip "
            f"to {state.destination} starting {state.start_date}.\n\n"
            "Use ALL inputs from previous agents:\n"
            "- Weather: schedule outdoor activities on good-weather days\n"
            "- Transport: include travel day logistics (arrival/departure times)\n"
            "- Hotels: include check-in and check-out in Day 1 and last day\n"
            "- Places: distribute attractions across days, cluster geographically\n"
            "- Budget: stay within the activities budget\n\n"
            f"Travel type: {state.travel_type}. "
            f"Interests: {', '.join(state.interests)}. "
            f"Food preference: {state.food_preference}.\n\n"
            "Day 1 should start with arrival and check-in. Last day ends with departure. "
            "Include morning, afternoon, and evening slots for each day. "
            "Add meal suggestions for breakfast, lunch, and dinner each day."
        ),
        expected_output=(
            "A structured JSON itinerary: { 'trip_title': str, 'days': [ { 'day': int, "
            "'date': str, 'theme': str, 'morning': str, 'afternoon': str, 'evening': str, "
            "'meals': {'breakfast': str, 'lunch': str, 'dinner': str}, "
            "'estimated_daily_cost': float } ] }. "
            "Also include: packing_tips (list) and emergency_contacts (dict)."
        ),
        agent=agent,
    )


def create_review_task(agent, state: TripState) -> Task:
    return Task(
        description=(
            f"Perform a comprehensive quality review of the complete trip plan for "
            f"{state.destination} (budget: Rs{state.budget:,.0f}, {state.travelers} traveler(s)).\n\n"
            "Check ALL of the following:\n"
            "1. BUDGET: Does total_allocated <= total_budget? Flag if over budget.\n"
            "2. DATES: Do hotel check-in/out match start_date/end_date?\n"
            "3. TRANSPORT: Is there a confirmed transport option for outbound + return?\n"
            "4. SCHEDULE: Are there any overlapping activities or impossible travel times?\n"
            "5. COMPLETENESS: Are all 6 sections present (weather, transport, hotel, "
            "   places, budget, itinerary)?\n"
            "6. LOGIC: Does the itinerary match the weather forecast?\n"
            "7. SAFETY: Are emergency contacts and travel tips included?\n\n"
            "If ANY check fails, list the specific issues. "
            "If all checks pass, explicitly state 'APPROVED FOR PDF GENERATION'."
        ),
        expected_output=(
            "A JSON review report with: overall_status ('APPROVED' or 'NEEDS_REVISION'), "
            "checks (dict of each check with pass/fail + notes), "
            "issues_found (list of specific problems), "
            "retry_agents (list of agent names that need to re-run), "
            "approval_message (str)."
        ),
        agent=agent,
    )


def create_memory_update_task(agent, state: TripState) -> Task:
    return Task(
        description=(
            f"Save the user's preferences from this trip to persistent memory for user '{state.user_id}'.\n\n"
            f"Preferences to save:\n"
            f"- preferred_hotel: {state.hotel_preference}\n"
            f"- preferred_food: {state.food_preference}\n"
            f"- preferred_transport: {state.transport_preference}\n"
            f"- travel_type: {state.travel_type}\n"
            f"- interests: {', '.join(state.interests)}\n"
            f"- last_destination: {state.destination}\n"
            f"- budget_range: {state.luxury_vs_budget}\n\n"
            f"Use tool: '{state.user_id}|preferred_hotel:{state.hotel_preference}|"
            f"preferred_food:{state.food_preference}|preferred_transport:{state.transport_preference}|"
            f"travel_type:{state.travel_type}|last_destination:{state.destination}'"
        ),
        expected_output=(
            "Confirmation that user preferences have been saved to persistent memory, "
            "with a summary of what was stored."
        ),
        agent=agent,
    )


def create_pdf_task(agent, state: TripState) -> Task:
    return Task(
        description=(
            f"Generate a professional PDF travel report for the {state.destination} trip.\n\n"
            "The PDF must include all 8 sections:\n"
            "1. Cover Page (trip summary)\n"
            "2. Weather Forecast\n"
            "3. Transport Options\n"
            "4. Hotel Recommendations\n"
            "5. Tourist Attractions\n"
            "6. Day-wise Itinerary\n"
            "7. Budget Summary\n"
            "8. Packing Checklist & Emergency Contacts\n\n"
            "Call the PDF generator with the complete trip data. "
            "Confirm the file path of the generated PDF."
        ),
        expected_output=(
            "Confirmation that the PDF has been generated successfully. "
            "Include: pdf_file_path, file_size_kb (approx), sections_included (list), "
            "and a message to the user on how to access the file."
        ),
        agent=agent,
    )
