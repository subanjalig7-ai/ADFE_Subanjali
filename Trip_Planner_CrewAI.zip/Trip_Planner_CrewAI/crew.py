import os
import sys
import json
from datetime import datetime

# Force UTF-8 output so CrewAI's emoji logging doesn't crash on Windows cp1252
if sys.stdout.encoding != 'utf-8':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
if sys.stderr.encoding != 'utf-8':
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

from crewai import Crew, Process

from state import TripState
from agents import (
    create_orchestrator_agent,
    create_user_input_agent,
    create_memory_agent,
    create_weather_agent,
    create_transport_agent,
    create_hotel_agent,
    create_places_agent,
    create_budget_agent,
    create_itinerary_agent,
    create_review_agent,
    create_pdf_agent,
)
from tasks import (
    create_user_input_task,
    create_memory_retrieval_task,
    create_weather_task,
    create_transport_task,
    create_hotel_task,
    create_places_task,
    create_budget_task,
    create_itinerary_task,
    create_review_task,
    create_memory_update_task,
    create_pdf_task,
)
from pdf_generator import generate_trip_pdf
from memory_manager import TripMemoryManager


class TripPlannerCrew:
    """
    Orchestrates the full multi-agent trip planning workflow using CrewAI
    hierarchical process where the Orchestrator supervises all specialist agents.
    """

    def __init__(self, trip_input: dict):
        self.model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
        self.state = TripState(
            user_id=trip_input.get("user_id", "user_001"),
            source=trip_input.get("source", ""),
            destination=trip_input.get("destination", ""),
            start_date=trip_input.get("start_date", ""),
            end_date=trip_input.get("end_date", ""),
            budget=float(trip_input.get("budget", 0)),
            travelers=int(trip_input.get("travelers", 1)),
            travel_type=trip_input.get("travel_type", "solo"),
            hotel_preference=trip_input.get("hotel_preference", "mid-range"),
            food_preference=trip_input.get("food_preference", "any"),
            transport_preference=trip_input.get("transport_preference", "any"),
            interests=[i.strip() for i in trip_input.get("interests", "").split(",") if i.strip()],
            luxury_vs_budget=trip_input.get("luxury_vs_budget", "budget"),
        )
        self.memory_manager = TripMemoryManager()
        self._build_agents()

    def _build_agents(self):
        m = self.model
        self.orchestrator = create_orchestrator_agent(m)
        self.user_input_agent = create_user_input_agent(m)
        self.memory_agent = create_memory_agent(m)
        self.weather_agent = create_weather_agent(m)
        self.transport_agent = create_transport_agent(m)
        self.hotel_agent = create_hotel_agent(m)
        self.places_agent = create_places_agent(m)
        self.budget_agent = create_budget_agent(m)
        self.itinerary_agent = create_itinerary_agent(m)
        self.review_agent = create_review_agent(m)
        self.pdf_agent = create_pdf_agent(m)

    def _build_tasks(self):
        s = self.state
        return [
            create_user_input_task(self.user_input_agent, s),
            create_memory_retrieval_task(self.memory_agent, s),
            create_weather_task(self.weather_agent, s),
            create_transport_task(self.transport_agent, s),
            create_hotel_task(self.hotel_agent, s),
            create_places_task(self.places_agent, s),
            create_budget_task(self.budget_agent, s),
            create_itinerary_task(self.itinerary_agent, s),
            create_review_task(self.review_agent, s),
            create_memory_update_task(self.memory_agent, s),
            create_pdf_task(self.pdf_agent, s),
        ]

    def run(self) -> dict:
        print(f"\n{'='*60}")
        print("  TRIP PLANNER CrewAI - ORCHESTRATOR STARTING")
        print(f"{'='*60}")
        print(f"  Destination : {self.state.destination}")
        print(f"  From        : {self.state.source}")
        print(f"  Dates       : {self.state.start_date} to {self.state.end_date}")
        print(f"  Budget      : Rs{self.state.budget:,.0f}")
        print(f"  Travelers   : {self.state.travelers} ({self.state.travel_type})")
        print(f"  Model       : {self.model}")
        print(f"{'='*60}\n")

        worker_agents = [
            self.user_input_agent,
            self.memory_agent,
            self.weather_agent,
            self.transport_agent,
            self.hotel_agent,
            self.places_agent,
            self.budget_agent,
            self.itinerary_agent,
            self.review_agent,
            self.pdf_agent,
        ]

        tasks = self._build_tasks()

        crew = Crew(
            agents=worker_agents,
            tasks=tasks,
            process=Process.hierarchical,
            manager_agent=self.orchestrator,
            memory=True,
            verbose=True,
            max_iter=15,
        )

        result = crew.kickoff()

        # Generate PDF with collected data
        pdf_path = self._generate_pdf(result)
        self.state.pdf_path = pdf_path

        # Persist trip to memory
        self.memory_manager.save_trip(self.state.user_id, {
            "destination": self.state.destination,
            "source": self.state.source,
            "start_date": self.state.start_date,
            "end_date": self.state.end_date,
            "budget": self.state.budget,
            "travelers": self.state.travelers,
        })

        return {
            "status": "completed",
            "destination": self.state.destination,
            "pdf_path": pdf_path,
            "crew_output": str(result),
        }

    def _generate_pdf(self, crew_result) -> str:
        result_str = str(crew_result)

        trip_data = {
            "source": self.state.source,
            "destination": self.state.destination,
            "start_date": self.state.start_date,
            "end_date": self.state.end_date,
            "budget": self.state.budget,
            "travelers": self.state.travelers,
            "travel_type": self.state.travel_type,
            "hotel_preference": self.state.hotel_preference,
            "food_preference": self.state.food_preference,
            "transport_preference": self.state.transport_preference,
            "weather_data": self._extract_section(result_str, "weather"),
            "transport_data": self._extract_section(result_str, "transport"),
            "hotel_data": self._extract_section(result_str, "hotel"),
            "places_data": self._extract_section(result_str, "places"),
            "budget_summary": self._extract_section(result_str, "budget"),
            "itinerary": self._extract_section(result_str, "itinerary"),
        }

        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        dest = self.state.destination.replace(" ", "_")
        output_path = f"TripPlan_{dest}_{ts}.pdf"
        pdf_path = generate_trip_pdf(trip_data, output_path)
        print(f"\nPDF generated: {pdf_path}")
        return pdf_path

    def _extract_section(self, text: str, keyword: str) -> dict:
        import re
        pattern = r'\{[^{}]*' + keyword + r'[^{}]*\}'
        matches = re.findall(pattern, text, re.IGNORECASE | re.DOTALL)
        for match in matches:
            try:
                return json.loads(match)
            except Exception:
                continue
        return {"summary": text[:800] + "..." if len(text) > 800 else text}
