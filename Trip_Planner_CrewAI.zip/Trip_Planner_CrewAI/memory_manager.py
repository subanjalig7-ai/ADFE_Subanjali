import json
import os
from datetime import datetime
from typing import Dict, Any, Optional, List


MEMORY_FILE = "trip_memory.json"


class TripMemoryManager:
    """Persistent JSON-based memory for storing user preferences and trip history."""

    def __init__(self, memory_file: str = MEMORY_FILE):
        self.memory_file = memory_file
        self.memory = self._load()

    def _load(self) -> Dict:
        if os.path.exists(self.memory_file):
            with open(self.memory_file, "r") as f:
                return json.load(f)
        return {"users": {}, "trips": []}

    def _save(self):
        with open(self.memory_file, "w") as f:
            json.dump(self.memory, f, indent=2, default=str)

    def save_preferences(self, user_id: str, preferences: Dict[str, Any]):
        if user_id not in self.memory["users"]:
            self.memory["users"][user_id] = {}
        self.memory["users"][user_id].update(preferences)
        self.memory["users"][user_id]["last_updated"] = datetime.now().isoformat()
        self._save()

    def get_preferences(self, user_id: str) -> Optional[Dict[str, Any]]:
        return self.memory["users"].get(user_id)

    def save_trip(self, user_id: str, trip_data: Dict[str, Any]):
        trip_data["user_id"] = user_id
        trip_data["saved_at"] = datetime.now().isoformat()
        self.memory["trips"].append(trip_data)
        self._save()

    def get_recent_trips(self, user_id: str, limit: int = 3) -> List[Dict]:
        user_trips = [t for t in self.memory["trips"] if t.get("user_id") == user_id]
        return sorted(user_trips, key=lambda x: x.get("saved_at", ""), reverse=True)[:limit]

    def get_all_users(self) -> List[str]:
        return list(self.memory["users"].keys())

    def format_preferences_for_agent(self, user_id: str) -> str:
        prefs = self.get_preferences(user_id)
        recent = self.get_recent_trips(user_id)
        if not prefs and not recent:
            return f"No previous history found for user '{user_id}'. This is a new user."
        output = f"User '{user_id}' preferences:\n"
        if prefs:
            for k, v in prefs.items():
                if k != "last_updated":
                    output += f"  - {k}: {v}\n"
        if recent:
            output += f"\nRecent trips ({len(recent)}):\n"
            for t in recent:
                output += f"  - {t.get('destination', 'N/A')} on {t.get('saved_at', 'N/A')[:10]}\n"
        return output
