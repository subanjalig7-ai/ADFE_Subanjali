import os
import sys
import json
import re
from datetime import datetime

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

from flask import Flask, render_template, request, send_file, abort
from dotenv import load_dotenv
from openai import OpenAI

from pdf_generator import generate_trip_pdf
from memory_manager import TripMemoryManager

load_dotenv()

app = Flask(__name__)
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
memory = TripMemoryManager()


# ── LLM helper ───────────────────────────────────────────────────────────────

def ask_agent(system_prompt: str, user_prompt: str) -> str:
    resp = client.chat.completions.create(
        model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user",   "content": user_prompt},
        ],
        temperature=0.4,
    )
    return resp.choices[0].message.content.strip()


def safe_json(text: str) -> dict:
    match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', text, re.DOTALL)
    if match:
        try: return json.loads(match.group(1))
        except: pass
    match = re.search(r'\{.*\}', text, re.DOTALL)
    if match:
        try: return json.loads(match.group(0))
        except: pass
    return {"raw_output": text}


# ── Routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/plan", methods=["POST"])
def plan():
    trip = {
        "user_id":             request.form.get("user_id", "user_001"),
        "source":              request.form.get("source", "Bangalore"),
        "destination":         request.form.get("destination", "Goa"),
        "start_date":          request.form.get("start_date", "2025-06-01"),
        "end_date":            request.form.get("end_date",   "2025-06-05"),
        "budget":              float(request.form.get("budget", 30000)),
        "travelers":           int(request.form.get("travelers", 2)),
        "travel_type":         request.form.get("travel_type", "couple"),
        "hotel_preference":    request.form.get("hotel_preference", "beach resort"),
        "food_preference":     request.form.get("food_preference", "non-veg"),
        "transport_preference":request.form.get("transport_preference", "flight"),
        "interests":           [i.strip() for i in request.form.get("interests", "beach,food").split(",")],
        "luxury_vs_budget":    request.form.get("luxury_vs_budget", "budget"),
    }

    agents_log = []

    def run(name: str, system: str, prompt: str) -> str:
        result = ask_agent(system, prompt)
        agents_log.append(f"{name} — completed")
        return result

    # ── Agent 1: Orchestrator ─────────────────────────────────────
    agents_log.append("Orchestrator — analysing trip & planning execution order")
    run("Orchestrator",
        "You are the Trip Planning Orchestrator. Plan agent execution order.",
        f"Trip: {json.dumps(trip, indent=2)}\nList the order agents should run.")

    # ── Agent 2: Memory ───────────────────────────────────────────
    agents_log.append(f"Memory Agent — loaded preferences for {trip['user_id']}")

    # ── Agent 3: Weather ──────────────────────────────────────────
    weather_raw = run("Weather Agent",
        "You are a weather specialist. Return a 5-day forecast as JSON.",
        f"Weather for {trip['destination']} {trip['start_date']} to {trip['end_date']}. "
        "Return JSON: city, forecast (5 items: date/temp/description/humidity), recommendation.")

    # ── Agent 4: Transport ────────────────────────────────────────
    transport_raw = run("Transport Agent",
        "You are a transport expert. Return options as JSON.",
        f"Transport from {trip['source']} to {trip['destination']} for {trip['travelers']} "
        f"travelers on {trip['start_date']}. Preference: {trip['transport_preference']}. "
        "Return JSON: route, options (mode/duration/cost_per_person/total_cost/airlines/booking_note), recommendation.")

    # ── Agent 5: Hotel ────────────────────────────────────────────
    hotel_raw = run("Hotel Agent",
        "You are a hospitality expert. Return options as JSON.",
        f"Hotels in {trip['destination']} for {trip['travelers']} travelers "
        f"{trip['start_date']} to {trip['end_date']}. "
        f"Budget: Rs{trip['budget']*0.35/4:.0f}/night. Preference: {trip['hotel_preference']}. "
        "Return JSON: city, nights, hotels (name/stars/rating/price_per_night/total_cost/amenities/location/booking), recommendation.")

    # ── Agent 6: Places ───────────────────────────────────────────
    places_raw = run("Places Explorer Agent",
        "You are a destination expert. Return places as JSON.",
        f"Attractions & food in {trip['destination']} for interests: {', '.join(trip['interests'])}. "
        "Return JSON: city, attractions (name/type/timing/entry/highlight), local_tips (list of 5).")

    # ── Agent 7: Budget ───────────────────────────────────────────
    budget_raw = run("Budget Agent",
        "You are a travel budget optimizer. Return breakdown as JSON.",
        f"Budget Rs{trip['budget']}, {trip['travelers']} travelers, 5 days, "
        f"hotel: {trip['hotel_preference']}, transport: {trip['transport_preference']}. "
        "Return JSON: total_budget, breakdown (intercity_transport/accommodation/food_and_dining/"
        "activities/local_transport/miscellaneous), total_allocated, savings_buffer, "
        "budget_status, per_person_budget, optimization_tips (list of 5).")

    # ── Agent 8: Itinerary ────────────────────────────────────────
    itinerary_raw = run("Itinerary Agent",
        "You are a master itinerary planner. Return day-wise plan as JSON.",
        f"5-day itinerary for {trip['destination']}, {trip['travel_type']} trip. "
        f"Interests: {', '.join(trip['interests'])}. Food: {trip['food_preference']}. "
        f"Start: {trip['start_date']}. Day 1=arrival, Day 5=departure. "
        "Return JSON: trip_title, days (list: day/date/theme/morning/afternoon/evening/"
        "meals{breakfast,lunch,dinner}/estimated_daily_cost).")

    # ── Agent 9: Review ───────────────────────────────────────────
    review_raw = run("Final Review Agent",
        "You are a QA specialist for travel plans.",
        f"Review budget: {budget_raw[:250]}\nHotel: {hotel_raw[:250]}\nItinerary: {itinerary_raw[:250]}\n"
        "Check budget compliance, date alignment, completeness. "
        "Return JSON: overall_status ('APPROVED' or 'NEEDS_REVISION'), approval_message.")

    # ── Agent 10: Memory save ─────────────────────────────────────
    memory.save_preferences(trip["user_id"], {
        "preferred_hotel": trip["hotel_preference"],
        "preferred_food":  trip["food_preference"],
        "preferred_transport": trip["transport_preference"],
        "last_destination": trip["destination"],
        "travel_type": trip["travel_type"],
    })
    memory.save_trip(trip["user_id"], {
        "destination": trip["destination"], "source": trip["source"],
        "start_date": trip["start_date"], "budget": trip["budget"],
        "travelers": trip["travelers"],
    })
    agents_log.append("Memory Agent — preferences & trip history saved")

    # ── Agent 11: PDF ─────────────────────────────────────────────
    agents_log.append("PDF Generator Agent — building 8-section report")
    trip_data = {
        **trip,
        "weather_data":   safe_json(weather_raw),
        "transport_data": safe_json(transport_raw),
        "hotel_data":     safe_json(hotel_raw),
        "places_data":    safe_json(places_raw),
        "budget_summary": safe_json(budget_raw),
        "itinerary":      safe_json(itinerary_raw),
    }
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    dest_slug = trip["destination"].replace(" ", "_")
    pdf_filename = f"TripPlan_{dest_slug}_{ts}.pdf"
    pdf_path = os.path.join(os.path.dirname(__file__), pdf_filename)
    generate_trip_pdf(trip_data, pdf_path)
    agents_log.append(f"PDF Generator Agent — report saved: {pdf_filename}")

    # ── Review status ─────────────────────────────────────────────
    review_json = safe_json(review_raw)
    review_status = review_json.get("overall_status", "APPROVED")

    return render_template("result.html",
        source=trip["source"],
        destination=trip["destination"],
        start_date=trip["start_date"],
        end_date=trip["end_date"],
        budget=int(trip["budget"]),
        travelers=trip["travelers"],
        travel_type=trip["travel_type"],
        hotel_preference=trip["hotel_preference"],
        transport_preference=trip["transport_preference"],
        agents=agents_log,
        review_status=review_status,
        itinerary_days=safe_json(itinerary_raw).get("days", []),
        itinerary_title=safe_json(itinerary_raw).get("trip_title", f"{trip['destination']} Trip Plan"),
        budget_preview=budget_raw[:800],
        pdf_filename=pdf_filename,
    )


@app.route("/download/<filename>")
def download(filename):
    path = os.path.join(os.path.dirname(__file__), filename)
    if not os.path.exists(path) or not filename.startswith("TripPlan_"):
        abort(404)
    return send_file(path, as_attachment=True,
                     download_name=filename, mimetype="application/pdf")


if __name__ == "__main__":
    print("\n" + "="*52)
    print("  AI Trip Planner - Web Interface")
    print("  Open: http://127.0.0.1:8080")
    print("="*52 + "\n")
    app.run(debug=False, port=8080)
