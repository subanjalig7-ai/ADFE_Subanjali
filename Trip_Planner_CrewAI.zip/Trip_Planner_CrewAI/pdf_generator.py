import json
import os
from datetime import datetime
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, PageBreak,
)
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT


BRAND_GREEN = colors.HexColor("#2E7D32")
BRAND_LIGHT = colors.HexColor("#E8F5E9")
ACCENT_ORANGE = colors.HexColor("#FF6F00")
DARK_GRAY = colors.HexColor("#37474F")
LIGHT_GRAY = colors.HexColor("#ECEFF1")


def _styles():
    base = getSampleStyleSheet()
    custom = {
        "cover_title": ParagraphStyle(
            "cover_title", parent=base["Title"],
            fontSize=28, textColor=BRAND_GREEN,
            spaceAfter=10, alignment=TA_CENTER, fontName="Helvetica-Bold",
        ),
        "cover_sub": ParagraphStyle(
            "cover_sub", parent=base["Normal"],
            fontSize=14, textColor=DARK_GRAY,
            spaceAfter=6, alignment=TA_CENTER,
        ),
        "section_heading": ParagraphStyle(
            "section_heading", parent=base["Heading1"],
            fontSize=16, textColor=BRAND_GREEN,
            spaceBefore=14, spaceAfter=6, fontName="Helvetica-Bold",
        ),
        "sub_heading": ParagraphStyle(
            "sub_heading", parent=base["Heading2"],
            fontSize=12, textColor=ACCENT_ORANGE,
            spaceBefore=8, spaceAfter=4, fontName="Helvetica-Bold",
        ),
        "body": ParagraphStyle(
            "body", parent=base["Normal"],
            fontSize=10, textColor=DARK_GRAY,
            spaceAfter=4, leading=15,
        ),
        "bullet": ParagraphStyle(
            "bullet", parent=base["Normal"],
            fontSize=10, textColor=DARK_GRAY,
            leftIndent=16, bulletIndent=6, spaceAfter=3, leading=14,
        ),
        "footer": ParagraphStyle(
            "footer", parent=base["Normal"],
            fontSize=8, textColor=colors.gray,
            alignment=TA_CENTER,
        ),
    }
    return custom


def _table_style():
    return TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), BRAND_GREEN),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, 0), 10),
        ("ALIGN", (0, 0), (-1, -1), "LEFT"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, BRAND_LIGHT]),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.lightgrey),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
    ])


def _section_divider():
    return HRFlowable(width="100%", thickness=1, color=BRAND_GREEN, spaceAfter=8)


def generate_trip_pdf(trip_data: dict, output_path: str = None) -> str:
    """
    Generates a professional multi-section trip plan PDF.
    Returns the path to the generated PDF file.
    """
    if not output_path:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        dest = trip_data.get("destination", "trip").replace(" ", "_")
        output_path = f"TripPlan_{dest}_{ts}.pdf"

    doc = SimpleDocTemplate(
        output_path,
        pagesize=A4,
        rightMargin=2 * cm,
        leftMargin=2 * cm,
        topMargin=2 * cm,
        bottomMargin=2 * cm,
    )

    s = _styles()
    story = []

    # ── Cover Page ───────────────────────────────────────────────────────────
    story.append(Spacer(1, 3 * cm))
    story.append(Paragraph("AI TRAVEL CONSULTANT", s["cover_title"]))
    story.append(Paragraph("Your Personalised Trip Plan", s["cover_sub"]))
    story.append(Spacer(1, 0.5 * cm))
    story.append(_section_divider())

    dest = trip_data.get("destination", "Destination")
    src = trip_data.get("source", "Source")
    story.append(Paragraph(f"✈  {src} → {dest}", s["cover_sub"]))
    story.append(Spacer(1, 0.3 * cm))

    cover_data = [
        ["Field", "Details"],
        ["Destination", trip_data.get("destination", "N/A")],
        ["Travel Dates", f"{trip_data.get('start_date', '')} to {trip_data.get('end_date', '')}"],
        ["Travelers", str(trip_data.get("travelers", 1))],
        ["Travel Type", trip_data.get("travel_type", "N/A").title()],
        ["Total Budget", f"₹{trip_data.get('budget', 0):,.0f}"],
        ["Hotel Preference", trip_data.get("hotel_preference", "N/A").title()],
        ["Transport Preference", trip_data.get("transport_preference", "N/A").title()],
        ["Food Preference", trip_data.get("food_preference", "N/A").title()],
        ["Generated On", datetime.now().strftime("%d %b %Y, %I:%M %p")],
    ]
    t = Table(cover_data, colWidths=[6 * cm, 10 * cm])
    t.setStyle(_table_style())
    story.append(t)
    story.append(PageBreak())

    # ── Section 1: Weather ───────────────────────────────────────────────────
    story.append(Paragraph("Section 1: Weather Forecast", s["section_heading"]))
    story.append(_section_divider())
    weather = trip_data.get("weather_data", {})
    if isinstance(weather, str):
        try:
            weather = json.loads(weather)
        except Exception:
            weather = {}

    story.append(Paragraph(
        weather.get("recommendation", "Check local forecast before travel."), s["body"]
    ))
    forecasts = weather.get("forecast", [])
    if forecasts:
        w_data = [["Day / Date", "Temperature", "Condition", "Humidity"]]
        for f in forecasts[:5]:
            w_data.append([
                f.get("date", f.get("datetime", "N/A")),
                f.get("temp", "N/A"),
                f.get("description", "N/A").title(),
                f.get("humidity", "N/A"),
            ])
        wt = Table(w_data, colWidths=[4 * cm, 3.5 * cm, 6 * cm, 3 * cm])
        wt.setStyle(_table_style())
        story.append(wt)
    story.append(Spacer(1, 0.5 * cm))
    story.append(PageBreak())

    # ── Section 2: Transport ─────────────────────────────────────────────────
    story.append(Paragraph("Section 2: Transport Options", s["section_heading"]))
    story.append(_section_divider())
    transport = trip_data.get("transport_data", {})
    if isinstance(transport, str):
        try:
            transport = json.loads(transport)
        except Exception:
            transport = {}

    story.append(Paragraph(
        f"Route: {transport.get('route', f'{src} → {dest}')}", s["sub_heading"]
    ))
    for opt in transport.get("options", []):
        story.append(Paragraph(f"▶  {opt.get('mode', 'N/A')}", s["sub_heading"]))
        rows = [["Attribute", "Details"]]
        for k, v in opt.items():
            if k not in ("mode",) and isinstance(v, (str, int, float)):
                rows.append([k.replace("_", " ").title(), str(v)])
        t = Table(rows, colWidths=[6 * cm, 10 * cm])
        t.setStyle(_table_style())
        story.append(t)
        story.append(Spacer(1, 0.3 * cm))
    story.append(PageBreak())

    # ── Section 3: Hotels ────────────────────────────────────────────────────
    story.append(Paragraph("Section 3: Hotel Recommendations", s["section_heading"]))
    story.append(_section_divider())
    hotels = trip_data.get("hotel_data", {})
    if isinstance(hotels, str):
        try:
            hotels = json.loads(hotels)
        except Exception:
            hotels = {}

    story.append(Paragraph(
        f"Stay: {hotels.get('nights', 'N/A')} nights in {dest}", s["body"]
    ))
    story.append(Paragraph(
        f"Recommended: {hotels.get('recommendation', 'N/A')}", s["body"]
    ))
    story.append(Spacer(1, 0.3 * cm))

    for hotel in hotels.get("hotels", [])[:3]:
        story.append(Paragraph(f"🏨  {hotel.get('name', 'N/A')} ({'⭐' * hotel.get('stars', 3)})", s["sub_heading"]))
        amenities = ", ".join(hotel.get("amenities", []))
        h_rows = [
            ["Attribute", "Details"],
            ["Rating", f"{hotel.get('rating', 'N/A')} / 5.0"],
            ["Price Per Night", f"₹{hotel.get('price_per_night', 0):,.0f}"],
            ["Total Stay Cost", f"₹{hotel.get('total_cost', 0):,.0f}"],
            ["Location", hotel.get("location", "N/A")],
            ["Amenities", amenities],
            ["Booking", hotel.get("booking", "N/A")],
        ]
        ht = Table(h_rows, colWidths=[6 * cm, 10 * cm])
        ht.setStyle(_table_style())
        story.append(ht)
        story.append(Spacer(1, 0.3 * cm))
    story.append(PageBreak())

    # ── Section 4: Tourist Attractions ──────────────────────────────────────
    story.append(Paragraph("Section 4: Tourist Attractions & Experiences", s["section_heading"]))
    story.append(_section_divider())
    places = trip_data.get("places_data", {})
    if isinstance(places, str):
        try:
            places = json.loads(places)
        except Exception:
            places = {}

    attractions = places.get("attractions", [])
    if attractions:
        p_rows = [["Place", "Type", "Timing", "Entry Fee", "Highlight"]]
        for pl in attractions[:10]:
            p_rows.append([
                pl.get("name", "N/A"),
                pl.get("type", "N/A"),
                pl.get("timing", "N/A"),
                pl.get("entry", pl.get("cuisine", "N/A")),
                pl.get("highlight", pl.get("avg_cost", "N/A")),
            ])
        pt = Table(p_rows, colWidths=[4 * cm, 2.5 * cm, 3 * cm, 2.5 * cm, 4.5 * cm])
        pt.setStyle(_table_style())
        story.append(pt)

    story.append(Spacer(1, 0.4 * cm))
    story.append(Paragraph("Local Tips", s["sub_heading"]))
    for tip in places.get("local_tips", []):
        story.append(Paragraph(f"• {tip}", s["bullet"]))
    story.append(PageBreak())

    # ── Section 5: Day-wise Itinerary ────────────────────────────────────────
    story.append(Paragraph("Section 5: Day-wise Itinerary", s["section_heading"]))
    story.append(_section_divider())
    itinerary = trip_data.get("itinerary", {})
    if isinstance(itinerary, str):
        try:
            itinerary = json.loads(itinerary)
        except Exception:
            itinerary = {}

    days = itinerary.get("days", [])
    if not days:
        story.append(Paragraph(
            str(itinerary) if itinerary else "Itinerary details will be filled by the Itinerary Agent.",
            s["body"],
        ))
    else:
        for day in days:
            story.append(Paragraph(
                f"Day {day.get('day', 'N/A')} – {day.get('date', '')}  |  {day.get('theme', '')}",
                s["sub_heading"],
            ))
            for slot in ["morning", "afternoon", "evening"]:
                activity = day.get(slot, "")
                if activity:
                    story.append(Paragraph(f"  {slot.title()}: {activity}", s["body"]))
            meals = day.get("meals", {})
            if meals:
                meal_str = " | ".join(f"{k.title()}: {v}" for k, v in meals.items())
                story.append(Paragraph(f"  Meals: {meal_str}", s["body"]))
            story.append(Spacer(1, 0.2 * cm))
    story.append(PageBreak())

    # ── Section 6: Budget Summary ────────────────────────────────────────────
    story.append(Paragraph("Section 6: Budget Summary", s["section_heading"]))
    story.append(_section_divider())
    budget = trip_data.get("budget_summary", {})
    if isinstance(budget, str):
        try:
            budget = json.loads(budget)
        except Exception:
            budget = {}

    status = budget.get("budget_status", "N/A")
    story.append(Paragraph(f"Status: {status}", s["sub_heading"]))

    breakdown = budget.get("breakdown", {})
    if breakdown:
        b_rows = [["Category", "Amount (INR)"]]
        for k, v in breakdown.items():
            b_rows.append([k.replace("_", " ").title(), f"₹{v:,.2f}"])
        b_rows.append(["TOTAL ALLOCATED", f"₹{budget.get('total_allocated', 0):,.2f}"])
        b_rows.append(["SAVINGS BUFFER", f"₹{budget.get('savings_buffer', 0):,.2f}"])
        bt = Table(b_rows, colWidths=[10 * cm, 6 * cm])
        bt.setStyle(_table_style())
        story.append(bt)

    story.append(Spacer(1, 0.4 * cm))
    story.append(Paragraph("Money-Saving Tips", s["sub_heading"]))
    for tip in budget.get("optimization_tips", []):
        story.append(Paragraph(f"• {tip}", s["bullet"]))
    story.append(PageBreak())

    # ── Section 7: Packing Checklist ─────────────────────────────────────────
    story.append(Paragraph("Section 7: Packing Checklist", s["section_heading"]))
    story.append(_section_divider())
    packing = [
        ("Documents", ["Aadhar / Passport", "Travel insurance", "Hotel booking confirmations",
                        "Flight / train tickets", "Emergency contacts printout"]),
        ("Clothing", ["Light cotton clothes", "Swimwear", "Comfortable walking shoes",
                      "Rain jacket / umbrella", "Sunglasses & hat"]),
        ("Health & Safety", ["Sunscreen SPF 50+", "Insect repellent", "Basic first aid kit",
                              "Prescribed medicines", "Hand sanitiser"]),
        ("Gadgets", ["Smartphone + charger", "Power bank", "Universal adapter",
                     "Camera / GoPro", "Earphones"]),
        ("Essentials", ["Wallet & cash (INR)", "Debit/credit cards", "Reusable water bottle",
                        "Snacks for journey", "Small backpack / day bag"]),
    ]
    for category, items in packing:
        story.append(Paragraph(category, s["sub_heading"]))
        for item in items:
            story.append(Paragraph(f"☐  {item}", s["bullet"]))
        story.append(Spacer(1, 0.2 * cm))
    story.append(PageBreak())

    # ── Section 8: Emergency Contacts ────────────────────────────────────────
    story.append(Paragraph("Section 8: Emergency Contacts & Travel Tips", s["section_heading"]))
    story.append(_section_divider())
    emergency = [
        ["Service", "Number"],
        ["National Emergency", "112"],
        ["Police", "100"],
        ["Ambulance", "108"],
        ["Fire", "101"],
        ["Tourist Helpline (India)", "1800-111-363"],
        ["Women Helpline", "1091"],
        ["Anti-Poison", "1066"],
    ]
    et = Table(emergency, colWidths=[8 * cm, 8 * cm])
    et.setStyle(_table_style())
    story.append(et)

    story.append(Spacer(1, 0.5 * cm))
    story.append(Paragraph("General Travel Safety Tips", s["sub_heading"]))
    safety_tips = [
        "Keep digital copies of all documents in email / cloud",
        "Inform a family member of your complete itinerary",
        "Avoid sharing trip details with strangers on social media",
        "Keep emergency cash (₹2,000+) separate from main wallet",
        "Use official/metered taxis; avoid unlicensed operators at night",
        "Stay hydrated – carry a water bottle at all times",
        "Purchase travel insurance for medical coverage",
    ]
    for tip in safety_tips:
        story.append(Paragraph(f"• {tip}", s["bullet"]))

    # Footer note
    story.append(Spacer(1, 1 * cm))
    story.append(_section_divider())
    story.append(Paragraph(
        f"Generated by AI Trip Planner (CrewAI) • {datetime.now().strftime('%d %b %Y')} • Have a wonderful trip!",
        s["footer"],
    ))

    doc.build(story)
    return output_path
