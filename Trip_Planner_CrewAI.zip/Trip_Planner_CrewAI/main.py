"""
Multi-Agent Trip Planner - CrewAI Implementation
Assignment: Production-Grade Agentic AI System

Agents:
  1.  Orchestrator Agent   - Supervisor, controls all agents
  2.  User Input Agent     - Validates trip requirements
  3.  Memory Agent         - Retrieves & updates user preferences
  4.  Weather Agent        - Fetches weather forecast
  5.  Transport Agent      - Finds flights/trains/car options
  6.  Hotel Agent          - Recommends hotels within budget
  7.  Places Explorer      - Discovers attractions & food
  8.  Budget Agent         - Calculates & optimises costs
  9.  Itinerary Agent      - Builds day-wise schedule
  10. Final Review Agent   - Validates completeness & consistency
  11. PDF Generator Agent  - Produces downloadable travel report
"""

import os
import sys

# Force UTF-8 so CrewAI's internal emoji logs don't crash on Windows cp1252
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
if hasattr(sys.stderr, 'reconfigure'):
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

from dotenv import load_dotenv
from crew import TripPlannerCrew

load_dotenv()


DEMO_TRIP = {
    "user_id": "user_001",
    "source": "Bangalore",
    "destination": "Goa",
    "start_date": "2025-06-01",
    "end_date": "2025-06-05",
    "budget": 200000,
    "travelers": 2,
    "travel_type": "couple",
    "hotel_preference": "beach resort",
    "food_preference": "non-veg",
    "transport_preference": "flight",
    "interests": "beach,nightlife,sightseeing,seafood",
    "luxury_vs_budget": "budget",
}


def get_user_input() -> dict:
    print("\n" + "=" * 60)
    print("    AI TRIP PLANNER  -  Powered by CrewAI")
    print("=" * 60)
    print("Press ENTER to accept demo values shown in [brackets].\n")

    def ask(prompt, default=""):
        val = input(f"{prompt} [{default}]: ").strip()
        return val if val else str(default)

    return {
        "user_id": ask("Your User ID", "user_001"),
        "source": ask("Source Location", "Bangalore"),
        "destination": ask("Destination", "Goa"),
        "start_date": ask("Start Date (YYYY-MM-DD)", "2025-06-01"),
        "end_date": ask("End Date (YYYY-MM-DD)", "2025-06-05"),
        "budget": float(ask("Total Budget (INR)", "200000")),
        "travelers": int(ask("Number of Travelers", "2")),
        "travel_type": ask("Travel Type (solo/couple/family/business)", "couple"),
        "hotel_preference": ask("Hotel Preference (budget/mid-range/luxury/beach resort)", "beach resort"),
        "food_preference": ask("Food Preference (veg/non-veg/any)", "non-veg"),
        "transport_preference": ask("Transport (flight/train/car/any)", "flight"),
        "interests": ask("Interests (comma-separated: beach,nightlife,heritage,food)", "beach,nightlife,sightseeing,seafood"),
        "luxury_vs_budget": ask("Luxury or Budget? (luxury/budget)", "budget"),
    }


def main():
    if not os.getenv("OPENAI_API_KEY"):
        print("\nWARNING: OPENAI_API_KEY not set.")
        print("   Create a .env file from .env.example and add your API key.")
        print("   Running in DEMO mode with mock data only.\n")

    use_demo = input("Use demo trip data? (y/n) [y]: ").strip().lower()
    trip_input = DEMO_TRIP if use_demo != "n" else get_user_input()

    print(f"\nStarting trip planning for {trip_input['destination']}...")

    planner = TripPlannerCrew(trip_input)
    result = planner.run()

    print("\n" + "=" * 60)
    print("  TRIP PLANNING COMPLETE!")
    print("=" * 60)
    print(f"  Destination : {result['destination']}")
    print(f"  PDF Report  : {result['pdf_path']}")
    print(f"  Status      : {result['status']}")
    print("=" * 60)
    print("\nOpen the PDF file to view your complete trip plan.")


if __name__ == "__main__":
    main()
