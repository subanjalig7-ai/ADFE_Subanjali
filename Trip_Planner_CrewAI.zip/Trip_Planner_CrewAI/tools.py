import os
import json
import requests
from datetime import datetime
from crewai.tools import tool
from memory_manager import TripMemoryManager

_memory = TripMemoryManager()


# --- Weather Tool ------------------------------------------------------------

@tool("Get Weather Forecast")
def get_weather_forecast(city_and_dates: str) -> str:
    """
    Fetches weather forecast for a destination city.
    Input format: 'city|start_date|end_date'  e.g. 'Goa|2025-06-01|2025-06-05'
    Returns temperature, conditions, and travel recommendations.
    """
    try:
        parts = city_and_dates.split("|")
        city = parts[0].strip()
        api_key = os.getenv("OPENWEATHER_API_KEY", "")

        if api_key:
            url = (
                f"http://api.openweathermap.org/data/2.5/forecast"
                f"?q={city}&appid={api_key}&units=metric&cnt=5"
            )
            resp = requests.get(url, timeout=10)
            if resp.status_code == 200:
                data = resp.json()
                items = data.get("list", [])[:5]
                forecasts = []
                for item in items:
                    forecasts.append({
                        "datetime": item["dt_txt"],
                        "temp": f"{item['main']['temp']}C",
                        "feels_like": f"{item['main']['feels_like']}C",
                        "description": item["weather"][0]["description"],
                        "humidity": f"{item['main']['humidity']}%",
                    })
                return json.dumps({
                    "city": city,
                    "forecast": forecasts,
                    "recommendation": _weather_recommendation(forecasts),
                }, indent=2)

        # Mock fallback
        return json.dumps({
            "city": city,
            "forecast": [
                {"date": "Day 1", "temp": "30C", "description": "Partly cloudy", "humidity": "70%"},
                {"date": "Day 2", "temp": "32C", "description": "Sunny", "humidity": "65%"},
                {"date": "Day 3", "temp": "29C", "description": "Light rain morning", "humidity": "80%"},
                {"date": "Day 4", "temp": "31C", "description": "Clear sky", "humidity": "68%"},
                {"date": "Day 5", "temp": "33C", "description": "Sunny and hot", "humidity": "62%"},
            ],
            "recommendation": (
                f"Weather in {city} is mostly pleasant. Pack light cotton clothes, "
                "sunscreen, and an umbrella for occasional showers."
            ),
        }, indent=2)
    except Exception as e:
        return f"Weather fetch error: {str(e)}. Advisory: carry light clothing and rain gear."


def _weather_recommendation(forecasts: list) -> str:
    rain_days = sum(1 for f in forecasts if "rain" in f.get("description", "").lower())
    if rain_days >= 3:
        return "Expect significant rainfall. Carry waterproof gear and plan indoor activities."
    elif rain_days >= 1:
        return "Some rain expected. An umbrella is recommended."
    return "Mostly pleasant weather. Great for outdoor activities."


# --- Transport Tool ----------------------------------------------------------

@tool("Search Transport Options")
def search_transport_options(trip_details: str) -> str:
    """
    Searches for transport options (flights, trains, buses) between cities.
    Input format: 'source|destination|date|travelers|preference'
    e.g. 'Bangalore|Goa|2025-06-01|2|flight'
    Returns available options with estimated costs.
    """
    try:
        parts = trip_details.split("|")
        source = parts[0].strip() if len(parts) > 0 else "source"
        destination = parts[1].strip() if len(parts) > 1 else "destination"
        date = parts[2].strip() if len(parts) > 2 else ""
        travelers = int(parts[3].strip()) if len(parts) > 3 else 1
        preference = parts[4].strip().lower() if len(parts) > 4 else "any"

        options = {
            "route": f"{source} to {destination}",
            "travel_date": date,
            "travelers": travelers,
            "options": [],
        }

        if preference in ("flight", "any"):
            options["options"].append({
                "mode": "Flight",
                "duration": "1h 15m",
                "cost_per_person": 4500,
                "total_cost": 4500 * travelers,
                "airlines": "IndiGo 6E-123 (07:30) | Air India AI-456 (14:00)",
                "booking_note": "Book 2-3 weeks in advance for best fares.",
            })

        if preference in ("train", "any"):
            options["options"].append({
                "mode": "Train",
                "duration": "10h 30m (overnight)",
                "cost_per_person": 1200,
                "total_cost": 1200 * travelers,
                "trains": "Goa Express 10103 (21:45) | Mandovi Express 10111 (07:30)",
                "booking_note": "Book via IRCTC. Tatkal quota available.",
            })

        if preference in ("car", "any"):
            options["options"].append({
                "mode": "Car / Road Trip",
                "duration": "9-10 hours",
                "cost": 4000 if travelers <= 4 else 7000,
                "fuel_estimate": "Rs 2,500 approx",
                "toll_estimate": "Rs 600 approx",
                "booking_note": "Self-drive or hire cab at Rs 12-15/km.",
            })

        options["recommendation"] = (
            "Flight recommended for comfort and speed."
            if preference == "flight"
            else "Train is the most economical option."
        )
        return json.dumps(options, indent=2)
    except Exception as e:
        return f"Transport search error: {str(e)}"


# --- Hotel Tool --------------------------------------------------------------

@tool("Search Hotels")
def search_hotels(hotel_query: str) -> str:
    """
    Searches for hotels at the destination within budget.
    Input format: 'city|check_in|check_out|travelers|budget_per_night|preference'
    e.g. 'Goa|2025-06-01|2025-06-05|2|3000|beach resort'
    Returns hotel options with ratings, amenities, and costs.
    """
    try:
        parts = hotel_query.split("|")
        city = parts[0].strip() if len(parts) > 0 else "city"
        nights = 4
        try:
            ci = datetime.strptime(parts[1].strip(), "%Y-%m-%d")
            co = datetime.strptime(parts[2].strip(), "%Y-%m-%d")
            nights = max(1, (co - ci).days)
        except Exception:
            pass
        travelers = int(parts[3].strip()) if len(parts) > 3 else 2
        budget_per_night = float(parts[4].strip()) if len(parts) > 4 else 3000
        preference = parts[5].strip().lower() if len(parts) > 5 else "any"

        hotels = []

        if "luxury" in preference or budget_per_night >= 8000:
            hotels.append({
                "name": f"Grand Taj Beach Resort {city}",
                "stars": 5,
                "rating": 4.7,
                "price_per_night": 9500,
                "total_cost": 9500 * nights,
                "amenities": "Private beach | Spa | Pool | Free WiFi | Breakfast included",
                "location": f"North {city} beachfront",
                "booking": "Book via official website or MakeMyTrip",
            })

        hotels += [
            {
                "name": f"Coconut Grove Guesthouse {city}",
                "stars": 3,
                "rating": 4.2,
                "price_per_night": min(budget_per_night, 3000),
                "total_cost": min(budget_per_night, 3000) * nights,
                "amenities": "Pool | Free WiFi | Breakfast | AC rooms",
                "location": f"Central {city}, 5 min from beach",
                "booking": "MakeMyTrip / Goibibo / OYO",
            },
            {
                "name": f"Budget Inn Express {city}",
                "stars": 2,
                "rating": 3.8,
                "price_per_night": min(budget_per_night * 0.5, 1500),
                "total_cost": min(budget_per_night * 0.5, 1500) * nights,
                "amenities": "Free WiFi | AC rooms | Parking",
                "location": f"Market area {city}",
                "booking": "OYO / Zostel / Booking.com",
            },
        ]

        return json.dumps({
            "city": city,
            "nights": nights,
            "travelers": travelers,
            "hotels": hotels,
            "recommendation": hotels[0]["name"],
            "booking_tip": "Book at least 2 weeks in advance for peak season discounts.",
        }, indent=2)
    except Exception as e:
        return f"Hotel search error: {str(e)}"


# --- Places Tool -------------------------------------------------------------

@tool("Get Tourist Places")
def get_tourist_places(query: str) -> str:
    """
    Retrieves tourist attractions, local experiences, and food recommendations.
    Input format: 'city|interests'
    e.g. 'Goa|beach,nightlife,seafood,heritage'
    Returns top attractions, local food spots, and experiences.
    """
    try:
        parts = query.split("|")
        city = parts[0].strip()
        interests = parts[1].strip().lower() if len(parts) > 1 else ""

        api_key = os.getenv("GOOGLE_PLACES_API_KEY", "")

        if api_key:
            url = (
                f"https://maps.googleapis.com/maps/api/place/textsearch/json"
                f"?query=tourist+attractions+in+{city}&key={api_key}"
            )
            resp = requests.get(url, timeout=10)
            if resp.status_code == 200:
                results = resp.json().get("results", [])[:8]
                places = [{"name": r["name"], "rating": r.get("rating", "N/A"),
                           "address": r.get("formatted_address", "")} for r in results]
                return json.dumps({"city": city, "places": places}, indent=2)

        all_places = {
            "beach": [
                {"name": "Baga Beach", "type": "Beach", "timing": "6AM-10PM",
                 "entry": "Free", "highlight": "Water sports, shacks, vibrant nightlife"},
                {"name": "Calangute Beach", "type": "Beach", "timing": "Open all day",
                 "entry": "Free", "highlight": "Largest beach, ideal for sunbathing"},
                {"name": "Anjuna Beach", "type": "Beach", "timing": "6AM-8PM",
                 "entry": "Free", "highlight": "Flea market on Wednesdays"},
            ],
            "heritage": [
                {"name": "Basilica of Bom Jesus", "type": "Heritage", "timing": "9AM-6:30PM",
                 "entry": "Free", "highlight": "UNESCO World Heritage Site, 16th century"},
                {"name": "Aguada Fort", "type": "Fort", "timing": "9:30AM-6PM",
                 "entry": "Free", "highlight": "Portuguese fort with lighthouse"},
            ],
            "nightlife": [
                {"name": "Tito's Club", "type": "Nightclub", "timing": "10PM-3AM",
                 "entry": "Rs 1000 couple", "highlight": "Legendary Goa nightclub"},
                {"name": "Leopard Valley", "type": "Nightclub", "timing": "9PM-4AM",
                 "entry": "Rs 800 couple", "highlight": "Open-air rave parties"},
            ],
            "food": [
                {"name": "Fisherman's Wharf", "type": "Restaurant", "timing": "Noon-11PM",
                 "cuisine": "Goan Seafood", "avg_cost": "Rs 800 per person"},
                {"name": "Gunpowder", "type": "Restaurant", "timing": "12PM-10:30PM",
                 "cuisine": "South Indian Coastal", "avg_cost": "Rs 600 per person"},
                {"name": "Baba Au Rhum", "type": "Cafe", "timing": "8AM-11PM",
                 "cuisine": "Continental + Goan", "avg_cost": "Rs 500 per person"},
            ],
        }

        selected = []
        for interest in ["beach", "heritage", "nightlife", "food"]:
            if not interests or interest in interests:
                selected.extend(all_places.get(interest, []))

        return json.dumps({
            "city": city,
            "total_attractions": len(selected),
            "attractions": selected,
            "local_tips": [
                "Rent a scooter (Rs 300/day) for easy mobility",
                "Try Goan fish curry rice at local shacks for authentic taste",
                "Avoid peak noon hours (12-3PM) for outdoor sightseeing",
                "Carry cash - many beach shacks don't accept cards",
            ],
        }, indent=2)
    except Exception as e:
        return f"Places search error: {str(e)}"


# --- Budget Tool -------------------------------------------------------------

@tool("Calculate Trip Budget")
def calculate_trip_budget(budget_input: str) -> str:
    """
    Calculates and optimizes the trip budget across all categories.
    Input format: 'total_budget|travelers|days|transport_cost|hotel_cost_per_night|hotel_preference'
    e.g. '30000|2|5|9000|3000|mid-range'
    Returns detailed budget breakdown and optimization tips.
    """
    try:
        parts = budget_input.split("|")
        total_budget = float(parts[0].strip()) if len(parts) > 0 else 30000
        travelers = int(parts[1].strip()) if len(parts) > 1 else 2
        days = int(parts[2].strip()) if len(parts) > 2 else 5
        transport_cost = float(parts[3].strip()) if len(parts) > 3 else 9000
        hotel_per_night = float(parts[4].strip()) if len(parts) > 4 else 3000
        preference = parts[5].strip().lower() if len(parts) > 5 else "mid-range"

        hotel_total = hotel_per_night * (days - 1)
        food_per_day = 600 * travelers if preference == "budget" else 1000 * travelers
        food_total = food_per_day * days
        activities = 500 * travelers * days if preference != "budget" else 300 * travelers * days
        miscellaneous = total_budget * 0.08
        local_transport = 400 * days

        allocated = transport_cost + hotel_total + food_total + activities + local_transport + miscellaneous
        savings = total_budget - allocated

        return json.dumps({
            "total_budget": total_budget,
            "breakdown": {
                "intercity_transport": transport_cost,
                "accommodation": hotel_total,
                "food_and_dining": food_total,
                "activities_and_sightseeing": activities,
                "local_transport": local_transport,
                "miscellaneous": round(miscellaneous, 2),
            },
            "total_allocated": round(allocated, 2),
            "savings_buffer": round(savings, 2),
            "budget_status": "Within Budget" if savings >= 0 else f"Over Budget by Rs {abs(savings):,.0f}",
            "per_person_budget": round(total_budget / travelers, 2),
            "optimization_tips": _budget_tips(savings, preference, hotel_per_night, days),
        }, indent=2)
    except Exception as e:
        return f"Budget calculation error: {str(e)}"


def _budget_tips(savings: float, preference: str, hotel_per_night: float, days: int) -> list:
    tips = ["Book flights 3-4 weeks in advance for 20-30% savings"]
    if savings < 0:
        tips += [
            f"Reduce hotel to Rs {max(800, hotel_per_night * 0.7):,.0f}/night by choosing a hostel or OYO",
            "Cook or buy from local markets instead of restaurants for 2 meals/day",
            "Skip luxury activities; free beaches and temples are equally rewarding",
        ]
    elif preference == "budget":
        tips += [
            "Use local buses (Rs 20-50/trip) instead of taxis",
            "Look for combo deals: hotel + breakfast packages",
            "Use Google Maps offline to avoid data charges",
        ]
    else:
        tips += [
            "You have a comfortable buffer - consider a day spa or sunset cruise",
            "Upgrade to a sea-facing room for a modest premium",
        ]
    return tips


# --- Memory Tools ------------------------------------------------------------

@tool("Save User Memory")
def save_user_memory(memory_data: str) -> str:
    """
    Saves user preferences to persistent memory for future trips.
    Input format: 'user_id|key1:value1|key2:value2|...'
    e.g. 'user_123|preferred_hotel:beach resort|food:seafood|transport:flight'
    """
    try:
        parts = memory_data.split("|")
        user_id = parts[0].strip()
        preferences = {}
        for item in parts[1:]:
            if ":" in item:
                k, v = item.split(":", 1)
                preferences[k.strip()] = v.strip()
        _memory.save_preferences(user_id, preferences)
        return f"Preferences saved for user '{user_id}': {preferences}"
    except Exception as e:
        return f"Memory save error: {str(e)}"


@tool("Load User Memory")
def load_user_memory(user_id: str) -> str:
    """
    Loads past preferences and trip history for a user.
    Input: user_id string  e.g. 'user_123'
    Returns stored preferences and recent trips.
    """
    try:
        return _memory.format_preferences_for_agent(user_id.strip())
    except Exception as e:
        return f"Memory load error: {str(e)}"
