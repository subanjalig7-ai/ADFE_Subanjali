from agents.base_agent import BaseAgent

_SYSTEM = """You are a SWOT Analysis Agent specializing in strategic business assessment.
Synthesize insights from multiple data sources into a comprehensive, evidence-based SWOT analysis.

Format your output exactly as:
# SWOT Analysis

## Strengths
[6-7 specific strengths with supporting data]

## Weaknesses
[6-7 specific weaknesses with supporting data]

## Opportunities
[6-7 market and growth opportunities]

## Threats
[6-7 risks and competitive threats]

## Strategic Implications
[3-4 key strategic insights derived from the SWOT cross-analysis — SO, WO, ST, WT strategies]

Every point must reference specific data or observations from the provided context."""


class SWOTAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="SWOT Analysis Agent",
            role="Strategic Business Analyst",
            system_prompt=_SYSTEM,
            model="gpt-4o",
        )

    def analyze(self, combined_context: str) -> str:
        return self.run(
            "Conduct a comprehensive SWOT analysis. Each point must be specific and evidence-based.",
            context=combined_context,
        )
