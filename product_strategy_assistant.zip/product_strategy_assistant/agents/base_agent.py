from openai import OpenAI
from typing import Optional


class BaseAgent:
    def __init__(self, name: str, role: str, system_prompt: str,
                 model: str = "gpt-4o-mini"):
        self.name = name
        self.role = role
        self.system_prompt = system_prompt
        self.model = model
        self.client = OpenAI()

    def run(self, task: str, context: Optional[str] = None) -> str:
        user_content = task
        if context:
            user_content = (
                f"<prior_agent_context>\n{context}\n</prior_agent_context>\n\n"
                f"<task>\n{task}\n</task>"
            )
        response = self.client.chat.completions.create(
            model=self.model,
            max_tokens=4096,
            messages=[
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": user_content},
            ],
        )
        return response.choices[0].message.content
