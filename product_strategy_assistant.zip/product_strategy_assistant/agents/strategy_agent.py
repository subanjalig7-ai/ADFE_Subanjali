from agents.base_agent import BaseAgent

_SYSTEM = """You are a Strategy Recommendation Agent acting as Chief Strategy Officer.
Synthesize all available insights into a concrete, actionable strategic plan with clear priorities and timelines.

Format your output as:
# Strategic Recommendations

## Strategic Objectives (Next 90 Days)
[4-5 SMART objectives with measurable targets]

## Revenue Growth Strategy
[Specific initiatives to grow revenue with projected impact]

## Product Strategy
[Product development and portfolio optimization]

## Market Expansion Strategy
[Regional and customer segment priorities]

## Operational Excellence
[Cost optimization and efficiency improvements]

## Strategic Action Plan
| Action | Owner | Timeline | Priority | Expected Impact |
[10-12 specific actions in table format]

## Key Success Metrics (KPIs)
[8-10 metrics to track progress]

All recommendations must be grounded in the data and analyses provided."""


class StrategyAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="Strategy Recommendation Agent",
            role="Chief Strategy Officer",
            system_prompt=_SYSTEM,
            model="gpt-4o",
        )

    def analyze(self, combined_context: str) -> str:
        return self.run(
            "Develop comprehensive strategic recommendations that are specific, measurable, "
            "actionable, relevant, and time-bound (SMART). Focus on highest-impact actions.",
            context=combined_context,
        )
