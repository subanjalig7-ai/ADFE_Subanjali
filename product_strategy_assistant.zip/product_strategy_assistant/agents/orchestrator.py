from openai import OpenAI
from typing import Callable, Optional

from agents.data_analytics_agent import DataAnalyticsAgent
from agents.customer_feedback_agent import CustomerFeedbackAgent
from agents.market_intelligence_agent import MarketIntelligenceAgent
from agents.swot_agent import SWOTAgent
from agents.feature_prioritization_agent import FeaturePrioritizationAgent
from agents.strategy_agent import StrategyAgent
from agents.executive_report_agent import ExecutiveReportAgent

_MAX_CONTEXT = 12000


def _trim(text: str, max_chars: int = _MAX_CONTEXT) -> str:
    return text[:max_chars] + "\n[...truncated...]" if len(text) > max_chars else text


class MultiAgentOrchestrator:
    def __init__(self):
        self.agents = {
            "data_analytics": DataAnalyticsAgent(),
            "customer_feedback": CustomerFeedbackAgent(),
            "market_intelligence": MarketIntelligenceAgent(),
            "swot": SWOTAgent(),
            "feature_prioritization": FeaturePrioritizationAgent(),
            "strategy": StrategyAgent(),
            "executive_report": ExecutiveReportAgent(),
        }
        self.results: dict = {}

    def run_analysis(
        self,
        data_summary: str,
        feedback_data: str,
        market_data: str,
        progress_callback: Optional[Callable[[str, float], None]] = None,
    ) -> dict:
        results = {}

        def _progress(msg: str, step: float) -> None:
            if progress_callback:
                progress_callback(msg, step)

        # Phase 1 — independent analysis
        _progress("Running Data Analytics Agent…", 1 / 7)
        results["data_analytics"] = self.agents["data_analytics"].analyze(data_summary)

        _progress("Running Customer Feedback Agent…", 2 / 7)
        results["customer_feedback"] = self.agents["customer_feedback"].analyze(feedback_data)

        _progress("Running Market Intelligence Agent…", 3 / 7)
        results["market_intelligence"] = self.agents["market_intelligence"].analyze(market_data)

        # Phase 2 — SWOT synthesis
        phase1_ctx = (
            "=== DATA ANALYTICS REPORT ===\n"
            + _trim(results["data_analytics"])
            + "\n\n=== CUSTOMER FEEDBACK REPORT ===\n"
            + _trim(results["customer_feedback"])
            + "\n\n=== MARKET INTELLIGENCE REPORT ===\n"
            + _trim(results["market_intelligence"])
        )
        _progress("Running SWOT Analysis Agent…", 4 / 7)
        results["swot"] = self.agents["swot"].analyze(phase1_ctx)

        # Phase 3 — feature prioritization
        phase2_ctx = phase1_ctx + "\n\n=== SWOT ANALYSIS ===\n" + _trim(results["swot"])
        _progress("Running Feature Prioritization Agent…", 5 / 7)
        results["feature_prioritization"] = self.agents["feature_prioritization"].analyze(phase2_ctx)

        # Phase 4 — strategy
        phase3_ctx = (
            phase2_ctx
            + "\n\n=== FEATURE PRIORITIZATION ===\n"
            + _trim(results["feature_prioritization"])
        )
        _progress("Running Strategy Recommendation Agent…", 6 / 7)
        results["strategy"] = self.agents["strategy"].analyze(phase3_ctx)

        # Phase 5 — executive report
        final_ctx = (
            phase3_ctx
            + "\n\n=== STRATEGIC RECOMMENDATIONS ===\n"
            + _trim(results["strategy"])
        )
        _progress("Running Executive Report Agent…", 7 / 7)
        results["executive_report"] = self.agents["executive_report"].compile(final_ctx)

        self.results = results
        return results

    def chat(self, user_message: str, conversation_history: list) -> str:
        client = OpenAI()

        context_block = ""
        if self.results:
            context_block = (
                "\n\nYou have access to a full product strategy analysis:\n\n"
                "EXECUTIVE REPORT:\n"
                + _trim(self.results.get("executive_report", "Not generated"), 3000)
                + "\n\nSWOT ANALYSIS:\n"
                + _trim(self.results.get("swot", "Not generated"), 2000)
                + "\n\nSTRATEGIC RECOMMENDATIONS:\n"
                + _trim(self.results.get("strategy", "Not generated"), 2000)
                + "\n\nDATA ANALYTICS:\n"
                + _trim(self.results.get("data_analytics", "Not generated"), 2000)
            )

        system = (
            "You are an AI Product Strategy Assistant. Help Product Managers make "
            "data-driven decisions based on the analysis of their business data. "
            "Answer questions clearly, cite specific data points when available, "
            "and provide actionable insights."
            + context_block
        )

        messages = [{"role": "system", "content": system}]
        for msg in conversation_history[-10:]:
            messages.append({"role": msg["role"], "content": msg["content"]})
        messages.append({"role": "user", "content": user_message})

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            max_tokens=2048,
            messages=messages,
        )
        return response.choices[0].message.content
