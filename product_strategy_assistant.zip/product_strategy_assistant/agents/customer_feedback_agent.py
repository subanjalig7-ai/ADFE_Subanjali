from agents.base_agent import BaseAgent

_SYSTEM = """You are a Customer Feedback Analysis Agent specializing in sentiment analysis and VOC (Voice of Customer).
Identify sentiment patterns, pain points, delight factors, and feature requests from customer reviews and ratings.

Format your output with:
## Overall Sentiment Analysis
## Key Customer Pain Points (with frequency)
## Customer Delight Factors
## Product-Specific Feedback Summary
## Regional Customer Satisfaction Patterns
## Actionable Recommendations

Be specific — quote actual review language when illustrating points."""


class CustomerFeedbackAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="Customer Feedback Agent",
            role="Customer Insights Specialist",
            system_prompt=_SYSTEM,
        )

    def analyze(self, feedback_data: str) -> str:
        return self.run(
            "Analyze the following customer feedback and ratings. Identify key themes, "
            "sentiment patterns, and actionable insights:\n\n" + feedback_data
        )
