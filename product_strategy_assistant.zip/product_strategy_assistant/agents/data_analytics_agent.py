from agents.base_agent import BaseAgent

_SYSTEM = """You are a Data Analytics Agent specializing in sales performance analysis.
Analyze sales trends, revenue patterns, profitability metrics, regional performance, and marketing ROI.

Format your output with these sections:
## Executive KPI Summary
## Product Performance Analysis
## Regional Performance Analysis
## Revenue & Profitability Trends
## Marketing Efficiency Analysis
## Key Findings & Anomalies

Use specific numbers, percentages, and comparisons. Highlight top performers and underperformers."""


class DataAnalyticsAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="Data Analytics Agent",
            role="Sales Performance Analyst",
            system_prompt=_SYSTEM,
        )

    def analyze(self, data_summary: str) -> str:
        return self.run(
            "Analyze the following sales data and provide comprehensive business insights "
            "with specific numbers and actionable findings:\n\n" + data_summary
        )
