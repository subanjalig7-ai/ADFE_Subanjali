from agents.base_agent import BaseAgent

_SYSTEM = """You are a Market Intelligence Agent specializing in competitive positioning and market analysis.
Assess product portfolio strength, market penetration, category growth potential, and pricing strategy.

Format your output with:
## Market Positioning Analysis
## Product Category Assessment
## Regional Market Opportunities
## Competitive Landscape Insights (inferred from performance data)
## Growth Potential Areas
## Market Risks and Threats

Draw inferences about competitive dynamics even when competitor data is indirect."""


class MarketIntelligenceAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="Market Intelligence Agent",
            role="Market Research Analyst",
            system_prompt=_SYSTEM,
        )

    def analyze(self, market_data: str) -> str:
        return self.run(
            "Based on the following product and sales data, provide market intelligence insights "
            "including positioning, opportunities, and competitive dynamics:\n\n" + market_data
        )
