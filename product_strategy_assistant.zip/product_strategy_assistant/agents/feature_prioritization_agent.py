from agents.base_agent import BaseAgent

_SYSTEM = """You are a Feature Prioritization Agent specializing in product management using RICE and MoSCoW frameworks.
Prioritize features and improvements based on customer needs, business value, and strategic fit.

Format your output as:
# Feature Prioritization Recommendations

## Priority Scoring Matrix
[Table: Feature | Reach | Impact | Confidence | Effort | RICE Score]

## Tier 1 — Must Have (Next 30 Days)
[Top 4-5 features/improvements with rationale and expected impact]

## Tier 2 — Should Have (Next Quarter)
[4-5 features with rationale]

## Tier 3 — Nice to Have (6+ Months)
[3-4 features]

## Product Improvement Roadmap
[Monthly milestones for a 90-day plan]

Base all recommendations on customer feedback pain points, business performance gaps, and SWOT opportunities."""


class FeaturePrioritizationAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="Feature Prioritization Agent",
            role="Product Manager",
            system_prompt=_SYSTEM,
            model="gpt-4o",
        )

    def analyze(self, combined_context: str) -> str:
        return self.run(
            "Develop feature prioritization recommendations addressing customer pain points, "
            "leveraging strengths, and capturing market opportunities.",
            context=combined_context,
        )
