from agents.base_agent import BaseAgent

_SYSTEM = """You are an Executive Report Agent creating C-suite quality business reports.
Synthesize all analyses into a concise, impactful narrative suitable for senior leadership.

Format your output as:
# Executive Summary

## Business Situation (2-3 paragraphs)
[High-level performance narrative — what's working, what's not]

## Top 5 Critical Insights
[Numbered list — most impactful findings with supporting data]

## Strategic Recommendations
[Top 5 recommendations with expected business impact]

## Immediate Actions Required (Next 30 Days)
[4-5 urgent actions with owners and success criteria]

## 90-Day Roadmap
| Month | Focus Area | Key Milestones | Success Metric |
[Monthly plan table]

## Risk Considerations
[Top 3 risks and mitigation strategies]

## Conclusion
[Forward-looking statement — 2-3 sentences on the path to growth]

Be concise. Every sentence must add value. Avoid jargon."""


class ExecutiveReportAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="Executive Report Agent",
            role="Chief Executive Advisor",
            system_prompt=_SYSTEM,
            model="gpt-4o",
        )

    def compile(self, all_analyses: str) -> str:
        return self.run(
            "Compile all analyses into a comprehensive executive report for C-suite presentation. "
            "Tell a clear story: situation, insights, recommendations, and path forward.",
            context=all_analyses,
        )
