import json
import os
from pathlib import Path

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from dotenv import load_dotenv

load_dotenv()

st.set_page_config(
    page_title="AI Product Strategy Assistant",
    page_icon="🎯",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
.main-header {
    background: linear-gradient(135deg, #1a365d 0%, #2c5282 100%);
    color: white; padding: 1.5rem 2rem; border-radius: 12px;
    margin-bottom: 1.5rem; text-align: center;
}
.main-header h1 { margin: 0; font-size: 1.9rem; }
.main-header p { margin: 0.3rem 0 0; opacity: 0.85; font-size: 1rem; }
.agent-badge {
    display: inline-block; padding: 3px 10px; border-radius: 12px;
    font-size: 0.8rem; font-weight: 600; margin: 2px;
}
.badge-done { background: #c6f6d5; color: #276749; }
.badge-wait { background: #fed7d7; color: #9b2c2c; }
div[data-testid="stMetricValue"] { font-size: 1.4rem; font-weight: 700; }
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="main-header">
  <h1>🎯 AI-Powered Product Strategy Assistant</h1>
  <p>7 specialized AI agents transform your business data into actionable strategic insights</p>
</div>
""", unsafe_allow_html=True)

# ── Session State ──────────────────────────────────────────────────────────────
for key, default in [
    ("analysis_results", None),
    ("df", None),
    ("stats", {}),
    ("processor", None),
    ("orchestrator", None),
    ("chat_history", []),
]:
    if key not in st.session_state:
        st.session_state[key] = default

# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## ⚙️ Configuration")
    api_key = st.text_input(
        "OpenAI API Key",
        value=os.getenv("OPENAI_API_KEY", ""),
        type="password",
        help="Required to run the AI agents (starts with sk-...)",
    )
    if api_key:
        os.environ["OPENAI_API_KEY"] = api_key

    st.markdown("---")
    st.markdown("### 📊 Analysis Status")
    if st.session_state.analysis_results:
        done = sum(1 for v in st.session_state.analysis_results.values() if v)
        st.success(f"✅ Analysis complete — {done}/7 agents")
    elif st.session_state.df is not None:
        st.info("📂 Data loaded — ready to analyze")
    else:
        st.warning("📤 Upload data to begin")

    st.markdown("---")
    st.markdown("### 🤖 Agent Pipeline")
    agent_labels = [
        "📈 Data Analytics",
        "💬 Customer Feedback",
        "🌐 Market Intelligence",
        "⚡ SWOT Analysis",
        "🎯 Feature Prioritization",
        "📋 Strategy Recommendation",
        "📄 Executive Report",
    ]
    agent_keys = [
        "data_analytics", "customer_feedback", "market_intelligence",
        "swot", "feature_prioritization", "strategy", "executive_report",
    ]
    for label, key in zip(agent_labels, agent_keys):
        if st.session_state.analysis_results and st.session_state.analysis_results.get(key):
            st.markdown(f'<span class="agent-badge badge-done">✓ {label}</span>', unsafe_allow_html=True)
        else:
            st.markdown(f'<span class="agent-badge badge-wait">○ {label}</span>', unsafe_allow_html=True)

# ── Tabs ───────────────────────────────────────────────────────────────────────
t1, t2, t3, t4, t5 = st.tabs([
    "📤 Upload & Analyze",
    "📊 Dashboard",
    "🤖 Agent Insights",
    "💬 Chat",
    "📄 Export",
])

# ═══════════════════════════════════════════════════════════════════════════════
# TAB 1 — Upload & Analyze
# ═══════════════════════════════════════════════════════════════════════════════
with t1:
    st.header("Data Ingestion & Multi-Agent Analysis")

    col_upload, col_cfg = st.columns([3, 2])

    with col_upload:
        st.subheader("1. Load Your Data")

        # ── Upload zone ──────────────────────────────────────────────────────
        st.markdown("**Option A — Upload your own CSV file**")
        uploaded = st.file_uploader(
            "Drag & drop or click Browse to upload",
            type=["csv"],
            label_visibility="visible",
            help="Supported columns: Date, Product_Name, Category, Region, "
                 "Units_Sold, Revenue_USD, Cost_USD, Profit_USD, "
                 "Marketing_Spend_USD, Customer_Rating, Returns, New_Customers, Review",
        )

        st.markdown("**Option B — Use built-in sample data**")
        use_sample = st.button(
            "📂 Load Sample Sales Data (120 records)",
            disabled=bool(uploaded),
        )

        # persist sample-load choice across reruns
        if use_sample:
            st.session_state["use_sample_data"] = True
        if uploaded:
            st.session_state["use_sample_data"] = False

        # ── Resolve file source ──────────────────────────────────────────────
        file_source = None
        if uploaded:
            file_source = uploaded
        elif st.session_state.get("use_sample_data"):
            sample_path = Path(__file__).parent / "data" / "sample_sales_data.csv"
            if sample_path.exists():
                file_source = str(sample_path)
            else:
                st.error("Sample file not found at data/sample_sales_data.csv")

        if file_source is not None:
            from core.data_processor import DataProcessor
            proc = DataProcessor()
            try:
                df = proc.load_csv(file_source)
                st.session_state.df = df
                st.session_state.stats = proc.stats
                st.session_state.processor = proc

                source_label = "uploaded file" if uploaded else "sample data"
                st.success(f"✅ Loaded **{len(df):,}** records from {source_label}")

                with st.expander("📋 Preview data (first 20 rows)", expanded=True):
                    st.dataframe(df.head(20), use_container_width=True)
                    c1, c2, c3, c4 = st.columns(4)
                    c1.metric("Records", f"{len(df):,}")
                    c2.metric("Products", df["Product_Name"].nunique())
                    c3.metric("Regions", df["Region"].nunique())
                    c4.metric("Categories", df["Category"].nunique())

                st.markdown("**Expected CSV columns:**")
                st.code(
                    "Date, Product_Name, Category, Region, Units_Sold,\n"
                    "Revenue_USD, Cost_USD, Profit_USD, Marketing_Spend_USD,\n"
                    "Customer_Rating, Returns, New_Customers, Review",
                    language="text",
                )
            except Exception as exc:
                st.error(f"Error loading file: {exc}")
                st.info("Make sure your CSV has the required columns listed above.")

    with col_cfg:
        st.subheader("2. Configure & Run")

        model_tier = st.radio(
            "Analysis Quality",
            ["Balanced (Recommended)", "Premium (slower, deeper)"],
            help="Premium uses Sonnet for all agents",
        )

        st.markdown("**Agents selected:** All 7 agents will run in sequence")
        st.markdown("*Phase 1:* Analytics → Feedback → Market (parallel concepts)")
        st.markdown("*Phase 2:* SWOT synthesis")
        st.markdown("*Phase 3:* Features → Strategy")
        st.markdown("*Phase 4:* Executive Report")

        st.markdown("---")
        can_run = (
            st.session_state.df is not None
            and bool(os.environ.get("OPENAI_API_KEY"))
        )
        run_btn = st.button(
            "🚀 Run Multi-Agent Analysis",
            use_container_width=True,
            disabled=not can_run,
            type="primary",
        )
        if not os.environ.get("OPENAI_API_KEY"):
            st.warning("⚠️ Enter your OpenAI API key in the sidebar first")
        elif st.session_state.df is None:
            st.info("Upload or select sample data above")

    # ── Run Analysis ──────────────────────────────────────────────────────────
    if run_btn and can_run:
        from agents.orchestrator import MultiAgentOrchestrator

        proc = st.session_state.processor
        orch = MultiAgentOrchestrator()
        st.session_state.orchestrator = orch

        prog_bar = st.progress(0.0, text="Initializing agents…")
        status = st.empty()

        def on_progress(msg: str, step: float) -> None:
            prog_bar.progress(step, text=msg)
            status.info(f"🔄 {msg}")

        with st.spinner("Running 7-agent pipeline — this may take 2-3 minutes…"):
            try:
                results = orch.run_analysis(
                    data_summary=proc.get_data_summary(),
                    feedback_data=proc.get_feedback_summary(),
                    market_data=proc.get_market_data_summary(),
                    progress_callback=on_progress,
                )
                st.session_state.analysis_results = results
                prog_bar.progress(1.0, text="All agents complete!")
                status.success("🎉 Analysis complete! Navigate to the other tabs to explore results.")
                st.balloons()
            except Exception as exc:
                st.error(f"Analysis failed: {exc}")
                st.exception(exc)

# ═══════════════════════════════════════════════════════════════════════════════
# TAB 2 — Dashboard
# ═══════════════════════════════════════════════════════════════════════════════
with t2:
    if st.session_state.df is None:
        st.info("👆 Load data in the Upload tab first.")
    else:
        df = st.session_state.df
        s = st.session_state.stats

        st.header("Business Performance Dashboard")

        # KPI row
        k1, k2, k3, k4, k5 = st.columns(5)
        k1.metric("💰 Revenue", f"${s['total_revenue']:,.0f}")
        k2.metric("📈 Profit", f"${s['total_profit']:,.0f}",
                  f"{s['profit_margin']:.1f}% margin")
        k3.metric("📦 Units Sold", f"{s['total_units']:,}")
        k4.metric("⭐ Avg Rating", f"{s['avg_rating']:.2f} / 5")
        k5.metric("🔄 Return Rate", f"{s['return_rate']:.1f}%")

        st.markdown("---")

        # Row 1: Revenue by product | Category pie
        col1, col2 = st.columns(2)
        with col1:
            prod_rev = (
                df.groupby("Product_Name")["Revenue_USD"]
                .sum()
                .reset_index()
                .sort_values("Revenue_USD")
            )
            fig = px.bar(
                prod_rev, x="Revenue_USD", y="Product_Name", orientation="h",
                title="Revenue by Product ($)", color="Revenue_USD",
                color_continuous_scale="Blues",
                labels={"Revenue_USD": "Revenue (USD)", "Product_Name": ""},
            )
            fig.update_layout(height=320, showlegend=False, coloraxis_showscale=False)
            st.plotly_chart(fig, use_container_width=True)

        with col2:
            cat_rev = df.groupby("Category")["Revenue_USD"].sum().reset_index()
            fig = px.pie(
                cat_rev, values="Revenue_USD", names="Category",
                title="Revenue Share by Category",
                color_discrete_sequence=px.colors.qualitative.Set2,
            )
            fig.update_layout(height=320)
            st.plotly_chart(fig, use_container_width=True)

        # Row 2: Monthly trend | Regional scatter
        col1, col2 = st.columns(2)
        with col1:
            df["_Month"] = df["Date"].dt.to_period("M").dt.to_timestamp()
            monthly = (
                df.groupby("_Month")
                .agg(Revenue=("Revenue_USD", "sum"), Profit=("Profit_USD", "sum"))
                .reset_index()
            )
            fig = go.Figure()
            fig.add_trace(go.Bar(
                x=monthly["_Month"], y=monthly["Revenue"],
                name="Revenue", marker_color="#3182ce",
            ))
            fig.add_trace(go.Bar(
                x=monthly["_Month"], y=monthly["Profit"],
                name="Profit", marker_color="#38a169",
            ))
            fig.update_layout(
                title="Monthly Revenue & Profit", barmode="group",
                height=320, legend=dict(orientation="h"),
            )
            st.plotly_chart(fig, use_container_width=True)

        with col2:
            reg = (
                df.groupby("Region")
                .agg(Revenue=("Revenue_USD", "sum"), New_Customers=("New_Customers", "sum"))
                .reset_index()
            )
            fig = px.scatter(
                reg, x="Revenue", y="New_Customers", text="Region",
                size="Revenue", color="Region",
                title="Regional Revenue vs New Customers",
                labels={"Revenue": "Revenue (USD)"},
            )
            fig.update_traces(textposition="top center")
            fig.update_layout(height=320, showlegend=False)
            st.plotly_chart(fig, use_container_width=True)

        # Row 3: Ratings | ROAS
        col1, col2 = st.columns(2)
        with col1:
            ratings = (
                df.groupby("Product_Name")["Customer_Rating"]
                .mean()
                .reset_index()
                .sort_values("Customer_Rating")
            )
            fig = px.bar(
                ratings, x="Customer_Rating", y="Product_Name", orientation="h",
                title="Avg Customer Rating by Product",
                color="Customer_Rating", color_continuous_scale="RdYlGn",
                range_color=[3.5, 5.0],
                labels={"Customer_Rating": "Rating", "Product_Name": ""},
            )
            fig.add_vline(x=4.0, line_dash="dash", line_color="red",
                          annotation_text="4.0 threshold")
            fig.update_layout(height=320, coloraxis_showscale=False)
            st.plotly_chart(fig, use_container_width=True)

        with col2:
            mktg = df.groupby("Product_Name").agg(
                Marketing=("Marketing_Spend_USD", "sum"),
                Revenue=("Revenue_USD", "sum"),
            ).reset_index()
            mktg["ROAS"] = (mktg["Revenue"] / mktg["Marketing"]).round(2)
            fig = px.bar(
                mktg, x="Product_Name", y="ROAS",
                title="Return on Ad Spend (ROAS) by Product",
                color="ROAS", color_continuous_scale="Greens",
            )
            fig.update_xaxes(tickangle=30)
            fig.update_layout(height=320, coloraxis_showscale=False)
            st.plotly_chart(fig, use_container_width=True)

        # Row 4: Treemap
        margin_df = df.groupby(["Category", "Product_Name"]).agg(
            Revenue=("Revenue_USD", "sum"),
            Profit=("Profit_USD", "sum"),
        ).reset_index()
        margin_df["Margin_%"] = (margin_df["Profit"] / margin_df["Revenue"] * 100).round(1)
        fig = px.treemap(
            margin_df, path=["Category", "Product_Name"],
            values="Revenue", color="Margin_%",
            color_continuous_scale="RdYlGn",
            title="Revenue Treemap — colour = profit margin %",
        )
        fig.update_layout(height=380)
        st.plotly_chart(fig, use_container_width=True)

        # Row 5: Return rate heatmap
        st.subheader("Return Rate by Product & Region")
        ret_pivot = df.pivot_table(
            values="Returns", index="Product_Name", columns="Region",
            aggfunc="sum", fill_value=0,
        )
        unit_pivot = df.pivot_table(
            values="Units_Sold", index="Product_Name", columns="Region",
            aggfunc="sum", fill_value=1,
        )
        rate_pivot = (ret_pivot / unit_pivot * 100).round(1)
        fig = px.imshow(
            rate_pivot, text_auto=True, aspect="auto",
            color_continuous_scale="Reds",
            title="Return Rate % (darker = higher returns)",
        )
        fig.update_layout(height=340)
        st.plotly_chart(fig, use_container_width=True)

# ═══════════════════════════════════════════════════════════════════════════════
# TAB 3 — Agent Insights
# ═══════════════════════════════════════════════════════════════════════════════
with t3:
    if st.session_state.analysis_results is None:
        st.info("👆 Run the analysis in the Upload tab first.")
    else:
        res = st.session_state.analysis_results
        st.header("Multi-Agent Analysis Results")

        agent_meta = [
            ("📈 Data Analytics Agent", "data_analytics",
             "Analyzes sales KPIs, product and regional performance, marketing ROI."),
            ("💬 Customer Feedback Agent", "customer_feedback",
             "Sentiment analysis, pain points, delight factors, and product-level feedback."),
            ("🌐 Market Intelligence Agent", "market_intelligence",
             "Market positioning, category growth, regional penetration, competitive dynamics."),
            ("⚡ SWOT Analysis Agent", "swot",
             "Synthesizes all Phase 1 outputs into a structured SWOT with strategic implications."),
            ("🎯 Feature Prioritization Agent", "feature_prioritization",
             "RICE-scored feature backlog and 90-day product roadmap."),
            ("📋 Strategy Recommendation Agent", "strategy",
             "SMART strategic objectives, action plan, and KPI targets."),
            ("📄 Executive Report Agent", "executive_report",
             "C-suite narrative — situation, critical insights, recommendations, 90-day roadmap."),
        ]

        for label, key, description in agent_meta:
            has_result = bool(res.get(key))
            status_icon = "✅" if has_result else "⏳"
            with st.expander(f"{status_icon} {label}", expanded=(key == "executive_report")):
                st.caption(description)
                if has_result:
                    st.markdown(res[key])
                else:
                    st.warning("This agent has not produced output yet.")

# ═══════════════════════════════════════════════════════════════════════════════
# TAB 4 — Chat
# ═══════════════════════════════════════════════════════════════════════════════
with t4:
    st.header("💬 Interactive Strategy Chat")

    if not os.environ.get("OPENAI_API_KEY"):
        st.warning("Enter your OpenAI API key in the sidebar to use the chat.")
    else:
        if st.session_state.analysis_results is None:
            st.info(
                "Tip: Run the full analysis first for richer, data-grounded answers. "
                "You can still chat without it."
            )

        # Display history
        for msg in st.session_state.chat_history:
            with st.chat_message(msg["role"]):
                st.markdown(msg["content"])

        prompt = st.chat_input(
            "Ask about your data, strategy, competitive position, product roadmap…"
        )
        if prompt:
            st.session_state.chat_history.append({"role": "user", "content": prompt})
            with st.chat_message("user"):
                st.markdown(prompt)

            with st.chat_message("assistant"):
                with st.spinner("Thinking…"):
                    try:
                        orch = st.session_state.orchestrator
                        if orch is None:
                            from agents.orchestrator import MultiAgentOrchestrator
                            orch = MultiAgentOrchestrator()
                            st.session_state.orchestrator = orch
                        if st.session_state.analysis_results:
                            orch.results = st.session_state.analysis_results

                        reply = orch.chat(
                            prompt,
                            st.session_state.chat_history[:-1],
                        )
                        st.markdown(reply)
                        st.session_state.chat_history.append(
                            {"role": "assistant", "content": reply}
                        )
                    except Exception as exc:
                        st.error(f"Chat error: {exc}")

        if st.session_state.chat_history and st.button("🗑️ Clear history"):
            st.session_state.chat_history = []
            st.rerun()

        st.markdown("---")
        st.markdown("**Suggested questions:**")
        suggestions = [
            "Which product has the best profit margin and why?",
            "What are the top 3 customer complaints?",
            "Which region should we prioritize for expansion?",
            "What features should we build in Q3?",
            "Summarize the SWOT analysis in 3 bullet points.",
        ]
        cols = st.columns(len(suggestions))
        for i, q in enumerate(suggestions):
            if cols[i].button(q, key=f"sug_{i}", use_container_width=True):
                st.session_state.chat_history.append({"role": "user", "content": q})
                st.rerun()

# ═══════════════════════════════════════════════════════════════════════════════
# TAB 5 — Export
# ═══════════════════════════════════════════════════════════════════════════════
with t5:
    st.header("📄 Export Reports")

    if st.session_state.analysis_results is None:
        st.info("Run the analysis first to generate downloadable reports.")
    else:
        res = st.session_state.analysis_results
        stats = st.session_state.stats

        col_dl, col_preview = st.columns([1, 2])

        with col_dl:
            st.subheader("Download Options")

            # PDF
            if st.button("Generate PDF Report", use_container_width=True, type="primary"):
                from core.pdf_generator import generate_pdf_report
                with st.spinner("Building PDF…"):
                    try:
                        pdf_bytes = generate_pdf_report(res, stats)
                        st.download_button(
                            "⬇️ Download PDF",
                            data=pdf_bytes,
                            file_name="product_strategy_report.pdf",
                            mime="application/pdf",
                            use_container_width=True,
                        )
                        st.success("PDF ready!")
                    except Exception as exc:
                        st.error(f"PDF error: {exc}")

            st.markdown("---")

            # Markdown
            md_parts = ["# AI Product Strategy Report\n"]
            for key, title in [
                ("executive_report", "Executive Summary"),
                ("data_analytics", "Data Analytics"),
                ("customer_feedback", "Customer Feedback"),
                ("market_intelligence", "Market Intelligence"),
                ("swot", "SWOT Analysis"),
                ("feature_prioritization", "Feature Prioritization"),
                ("strategy", "Strategic Recommendations"),
            ]:
                if res.get(key):
                    md_parts.append(f"## {title}\n\n{res[key]}\n\n---\n")
            md_content = "\n".join(md_parts)

            st.download_button(
                "⬇️ Download Markdown Report",
                data=md_content,
                file_name="product_strategy_report.md",
                mime="text/markdown",
                use_container_width=True,
            )

            # JSON
            st.download_button(
                "⬇️ Download JSON (raw agent outputs)",
                data=json.dumps(res, indent=2),
                file_name="agent_analysis_results.json",
                mime="application/json",
                use_container_width=True,
            )

        with col_preview:
            st.subheader("Preview")
            choice = st.selectbox(
                "Select section",
                [
                    "Executive Summary", "SWOT Analysis",
                    "Strategic Recommendations", "Feature Prioritization",
                    "Customer Feedback", "Market Intelligence", "Data Analytics",
                ],
            )
            key_map = {
                "Executive Summary": "executive_report",
                "SWOT Analysis": "swot",
                "Strategic Recommendations": "strategy",
                "Feature Prioritization": "feature_prioritization",
                "Customer Feedback": "customer_feedback",
                "Market Intelligence": "market_intelligence",
                "Data Analytics": "data_analytics",
            }
            section_key = key_map[choice]
            if res.get(section_key):
                st.markdown(res[section_key])
            else:
                st.warning("Section not generated yet.")
