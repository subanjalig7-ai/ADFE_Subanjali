import pandas as pd
import numpy as np
from io import StringIO
from pathlib import Path


class DataProcessor:
    def __init__(self):
        self.df: pd.DataFrame = None
        self.stats: dict = {}

    def load_csv(self, source) -> pd.DataFrame:
        self.df = pd.read_csv(source)
        if "Date" in self.df.columns:
            self.df["Date"] = pd.to_datetime(self.df["Date"])
        self._compute_stats()
        return self.df

    def _compute_stats(self) -> None:
        df = self.df
        rev = df["Revenue_USD"].sum()
        profit = df["Profit_USD"].sum()
        units = df["Units_Sold"].sum()
        returns = df["Returns"].sum()
        self.stats = {
            "total_records": len(df),
            "total_revenue": rev,
            "total_profit": profit,
            "total_units": int(units),
            "total_marketing_spend": df["Marketing_Spend_USD"].sum(),
            "avg_rating": df["Customer_Rating"].mean(),
            "total_returns": int(returns),
            "total_new_customers": int(df["New_Customers"].sum()),
            "profit_margin": (profit / rev * 100) if rev else 0,
            "return_rate": (returns / units * 100) if units else 0,
        }

    def get_data_summary(self) -> str:
        df = self.df
        s = self.stats

        prod = df.groupby("Product_Name").agg(
            Revenue=("Revenue_USD", "sum"),
            Profit=("Profit_USD", "sum"),
            Units=("Units_Sold", "sum"),
            Avg_Rating=("Customer_Rating", "mean"),
            Returns=("Returns", "sum"),
            Marketing=("Marketing_Spend_USD", "sum"),
        ).round(2)
        prod["Profit_Margin_%"] = (prod["Profit"] / prod["Revenue"] * 100).round(1)
        prod["Return_Rate_%"] = (prod["Returns"] / prod["Units"] * 100).round(1)
        prod["ROAS"] = (prod["Revenue"] / prod["Marketing"]).round(2)

        region = df.groupby("Region").agg(
            Revenue=("Revenue_USD", "sum"),
            Profit=("Profit_USD", "sum"),
            Units=("Units_Sold", "sum"),
            New_Customers=("New_Customers", "sum"),
            Avg_Rating=("Customer_Rating", "mean"),
        ).round(2)

        category = df.groupby("Category").agg(
            Revenue=("Revenue_USD", "sum"),
            Profit=("Profit_USD", "sum"),
            Units=("Units_Sold", "sum"),
            Avg_Rating=("Customer_Rating", "mean"),
        ).round(2)
        category["Rev_Share_%"] = (category["Revenue"] / category["Revenue"].sum() * 100).round(1)

        df["Month"] = df["Date"].dt.to_period("M")
        monthly = df.groupby("Month").agg(
            Revenue=("Revenue_USD", "sum"),
            Profit=("Profit_USD", "sum"),
            Units=("Units_Sold", "sum"),
        ).round(2)

        return f"""
DATASET OVERVIEW:
  Records: {s['total_records']} | Date: {df['Date'].min().date()} to {df['Date'].max().date()}
  Products: {df['Product_Name'].nunique()} | Regions: {', '.join(df['Region'].unique())}
  Categories: {', '.join(df['Category'].unique())}

KEY FINANCIAL KPIs:
  Total Revenue:        ${s['total_revenue']:>12,.2f}
  Total Profit:         ${s['total_profit']:>12,.2f}
  Profit Margin:        {s['profit_margin']:>11.1f}%
  Total Units Sold:     {s['total_units']:>12,}
  Marketing Spend:      ${s['total_marketing_spend']:>12,.2f}
  Avg Customer Rating:  {s['avg_rating']:>12.2f} / 5.0
  Overall Return Rate:  {s['return_rate']:>11.1f}%
  Total New Customers:  {s['total_new_customers']:>12,}

PRODUCT PERFORMANCE:
{prod.to_string()}

REGIONAL PERFORMANCE:
{region.to_string()}

CATEGORY REVENUE SHARE:
{category.to_string()}

MONTHLY REVENUE & PROFIT TRENDS:
{monthly.to_string()}
"""

    def get_feedback_summary(self) -> str:
        df = self.df

        rating_dist = df["Customer_Rating"].value_counts().sort_index()
        prod_ratings = df.groupby("Product_Name")["Customer_Rating"].agg(
            Mean="mean", Count="count", Std="std"
        ).round(2)

        negative = df[df["Customer_Rating"] < 4.0][
            ["Product_Name", "Region", "Customer_Rating", "Review"]
        ].sort_values("Customer_Rating").head(25)

        positive = df[df["Customer_Rating"] >= 4.7][
            ["Product_Name", "Region", "Customer_Rating", "Review"]
        ].sort_values("Customer_Rating", ascending=False).head(25)

        all_reviews = df[
            ["Product_Name", "Region", "Customer_Rating", "Review", "Returns"]
        ].to_string(index=False)

        return f"""
FEEDBACK OVERVIEW:
  Total Reviews: {len(df)} | Avg Rating: {df['Customer_Rating'].mean():.2f}/5.0
  Ratings Distribution:
{rating_dist.to_string()}

PRODUCT RATINGS DETAIL:
{prod_ratings.to_string()}

NEGATIVE REVIEWS (Rating < 4.0) — top 25:
{negative.to_string(index=False)}

HIGHLY POSITIVE REVIEWS (Rating >= 4.7) — top 25:
{positive.to_string(index=False)}

ALL CUSTOMER REVIEWS:
{all_reviews}
"""

    def get_market_data_summary(self) -> str:
        df = self.df

        cat_share = (
            df.groupby("Category")["Revenue_USD"].sum()
        )
        cat_pct = (cat_share / cat_share.sum() * 100).round(2)

        avg_price = df.groupby("Product_Name").apply(
            lambda x: x["Revenue_USD"].sum() / x["Units_Sold"].sum()
        ).round(2)

        region_prod = (
            df.groupby(["Region", "Product_Name"])["Units_Sold"]
            .sum()
            .unstack(fill_value=0)
        )

        df["Month"] = df["Date"].dt.to_period("M")
        monthly_cat = (
            df.groupby(["Month", "Category"])["Revenue_USD"]
            .sum()
            .unstack(fill_value=0)
        )

        high_return = (
            df.groupby("Product_Name")
            .apply(lambda x: (x["Returns"].sum() / x["Units_Sold"].sum() * 100))
            .round(2)
            .sort_values(ascending=False)
        )

        return f"""
MARKET OVERVIEW:
  Products: {df['Product_Name'].nunique()} | Categories: {df['Category'].nunique()} | Regions: {df['Region'].nunique()}

REVENUE MARKET SHARE BY CATEGORY:
{cat_pct.to_string()}

AVERAGE SELLING PRICE BY PRODUCT (USD):
{avg_price.to_string()}

REGIONAL PRODUCT PENETRATION (Units Sold):
{region_prod.to_string()}

MONTHLY REVENUE TRENDS BY CATEGORY:
{monthly_cat.to_string()}

RETURN RATE BY PRODUCT (%):
{high_return.to_string()}
"""
