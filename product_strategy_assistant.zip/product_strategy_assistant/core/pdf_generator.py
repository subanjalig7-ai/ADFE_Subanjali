import io
from datetime import datetime

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    HRFlowable,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


def generate_pdf_report(results: dict, stats: dict) -> bytes:
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=60,
        leftMargin=60,
        topMargin=60,
        bottomMargin=40,
    )

    styles = getSampleStyleSheet()
    title_s = ParagraphStyle(
        "Title", parent=styles["Title"],
        fontSize=22, textColor=colors.HexColor("#1a365d"),
        alignment=TA_CENTER, spaceAfter=6,
    )
    subtitle_s = ParagraphStyle(
        "Subtitle", parent=styles["Normal"],
        fontSize=11, textColor=colors.HexColor("#4a5568"),
        alignment=TA_CENTER, spaceAfter=20,
    )
    h2_s = ParagraphStyle(
        "H2", parent=styles["Heading2"],
        fontSize=14, textColor=colors.HexColor("#2c5282"),
        spaceBefore=16, spaceAfter=6,
    )
    h3_s = ParagraphStyle(
        "H3", parent=styles["Heading3"],
        fontSize=11, textColor=colors.HexColor("#2d3748"),
        spaceBefore=10, spaceAfter=4,
    )
    body_s = ParagraphStyle(
        "Body", parent=styles["Normal"],
        fontSize=9, leading=14, spaceAfter=4, alignment=TA_JUSTIFY,
    )
    bullet_s = ParagraphStyle(
        "Bullet", parent=styles["Normal"],
        fontSize=9, leading=14, spaceAfter=3, leftIndent=14,
    )

    story = []

    # ── Cover ──────────────────────────────────────────────────────────────
    story.append(Spacer(1, 0.8 * inch))
    story.append(Paragraph("AI-Powered Product Strategy Report", title_s))
    story.append(Paragraph(
        f"Generated on {datetime.now().strftime('%B %d, %Y  |  %H:%M')}",
        subtitle_s,
    ))
    story.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor("#2c5282")))
    story.append(Spacer(1, 0.4 * inch))

    # ── KPI Table ──────────────────────────────────────────────────────────
    if stats:
        story.append(Paragraph("Key Performance Indicators", h2_s))
        kpi_rows = [
            ["Metric", "Value"],
            ["Total Revenue", f"${stats.get('total_revenue', 0):,.2f}"],
            ["Total Profit", f"${stats.get('total_profit', 0):,.2f}"],
            ["Profit Margin", f"{stats.get('profit_margin', 0):.1f}%"],
            ["Total Units Sold", f"{stats.get('total_units', 0):,}"],
            ["Avg Customer Rating", f"{stats.get('avg_rating', 0):.2f} / 5.0"],
            ["Return Rate", f"{stats.get('return_rate', 0):.1f}%"],
            ["Total New Customers", f"{stats.get('total_new_customers', 0):,}"],
        ]
        tbl = Table(kpi_rows, colWidths=[3 * inch, 3 * inch])
        tbl.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2c5282")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, 0), 11),
            ("FONTSIZE", (0, 1), (-1, -1), 9),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#ebf8ff")]),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ]))
        story.append(tbl)
        story.append(Spacer(1, 0.3 * inch))

    # ── Agent Sections ─────────────────────────────────────────────────────
    sections = [
        ("Executive Summary", "executive_report"),
        ("Data Analytics Report", "data_analytics"),
        ("Customer Feedback Analysis", "customer_feedback"),
        ("Market Intelligence Report", "market_intelligence"),
        ("SWOT Analysis", "swot"),
        ("Feature Prioritization Recommendations", "feature_prioritization"),
        ("Strategic Recommendations", "strategy"),
    ]

    for section_title, key in sections:
        if not results.get(key):
            continue
        story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#cbd5e0")))
        story.append(Spacer(1, 0.1 * inch))
        story.append(Paragraph(section_title, h2_s))

        for line in results[key].split("\n"):
            line = line.strip()
            if not line:
                story.append(Spacer(1, 0.05 * inch))
                continue

            # Escape XML entities
            safe = line.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

            if line.startswith("# "):
                story.append(Paragraph(safe[2:], h2_s))
            elif line.startswith("## "):
                story.append(Paragraph(safe[3:], h2_s))
            elif line.startswith("### "):
                story.append(Paragraph(safe[4:], h3_s))
            elif line.startswith(("- ", "* ", "• ")):
                story.append(Paragraph(f"• {safe[2:]}", bullet_s))
            elif line.startswith("|"):
                pass  # skip markdown tables — handled in text form
            else:
                try:
                    story.append(Paragraph(safe, body_s))
                except Exception:
                    pass

        story.append(Spacer(1, 0.2 * inch))

    doc.build(story)
    value = buffer.getvalue()
    buffer.close()
    return value
