# AI-Powered Finance Policy Assistant

An end-to-end Retrieval-Augmented Generation (RAG) system that answers employee
questions about internal finance policies using semantic search and GPT-4o-mini.

---

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                    DOCUMENT INGESTION PIPELINE                   │
│                                                                  │
│  Finance Policy .txt Files (6 documents)                         │
│         │                                                        │
│         ▼                                                        │
│  TextLoader (langchain_community)                                │
│         │  + source & category metadata                          │
│         ▼                                                        │
│  RecursiveCharacterTextSplitter                                  │
│  chunk_size=500, overlap=80                                      │
│         │  ~120–150 chunks                                       │
│         ▼                                                        │
│  OpenAIEmbeddings (text-embedding-3-small)                       │
│         │  1536-dim vectors                                      │
│         ▼                                                        │
│  FAISS Index  ──── saved to faiss_index/ ────►  Disk Cache       │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                      QUERY PIPELINE                              │
│                                                                  │
│  Employee Natural-Language Question                              │
│         │                                                        │
│         ▼                                                        │
│  OpenAIEmbeddings (text-embedding-3-small)                       │
│         │  query vector                                          │
│         ▼                                                        │
│  FAISS Similarity Search  (top-k = 4 chunks)                     │
│         │  retrieved context + source metadata                   │
│         ▼                                                        │
│  create_stuff_documents_chain                                    │
│  (context injected into system prompt)                           │
│         │                                                        │
│         ▼                                                        │
│  GPT-4o-mini  (temperature=0.1)                                  │
│         │                                                        │
│         ▼                                                        │
│  Grounded Answer  +  Source Citations                            │
└─────────────────────────────────────────────────────────────────┘
```

---

## Project Structure

```
finance_policy_assistant/
├── __init__.py               # Package description & architecture overview
├── config.py                 # OpenAI API key setup
├── ingestion.py              # Document loading and chunking
├── vectorstore.py            # FAISS index build/load and retriever
├── chain.py                  # RAG chain assembly and query helper
├── app.py                    # CLI application (interactive + demo mode)
├── requirements.txt          # Python dependencies
├── README.md                 # This file
├── documents/                # Sample finance policy documents
│   ├── reimbursement_policy.txt
│   ├── travel_expense_rules.txt
│   ├── vendor_payment_procedures.txt
│   ├── tax_compliance_guidelines.txt
│   ├── procurement_approvals.txt
│   └── employee_finance_handbook.txt
└── faiss_index/              # Auto-created after first run
```

---

## Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Set your OpenAI API key
```bash
# Option A – environment variable (recommended)
export OPENAI_API_KEY=sk-...

# Option B – the app will prompt you on first run
```

### 3. Run the assistant
```bash
# Interactive mode (from the parent directory)
python -m finance_policy_assistant.app

# Demo mode – runs 10 pre-defined queries
python -m finance_policy_assistant.app --demo

# Force rebuild the vector index
python -m finance_policy_assistant.app --rebuild
```

---

## Sample Queries and Expected Topics

| # | Query | Policy Document |
|---|-------|-----------------|
| 1 | What is the reimbursement limit for client travel meals? | reimbursement_policy |
| 2 | What approvals are needed for a $15,000 vendor payment? | vendor_payment_procedures |
| 3 | Can international expenses be claimed? | travel_expense_rules |
| 4 | What documents are required for a $8,000 procurement? | procurement_approvals |
| 5 | What is the mileage rate for a personal vehicle? | travel_expense_rules |
| 6 | When do I need to file a 1099-NEC? | tax_compliance_guidelines |
| 7 | What is the domestic hotel accommodation limit? | reimbursement_policy |
| 8 | How do I submit an expense report? | employee_finance_handbook |
| 9 | Are business class flights allowed? | travel_expense_rules |
| 10 | What are the standard vendor payment terms? | vendor_payment_procedures |

---

## Technical Documentation

### System Design Decisions

**LangChain orchestration** was chosen for its modular retrieval chain primitives
(`create_retrieval_chain`, `create_stuff_documents_chain`) that cleanly separate
retrieval from generation and make source documents natively accessible.

**FAISS** was selected as the vector store for its zero-infrastructure overhead and
fast in-process similarity search, ideal for a static policy document corpus.
The index is persisted to disk so subsequent runs skip the embedding step.

**GPT-4o-mini** balances cost and quality for enterprise Q&A: low hallucination
rate on factual retrieval tasks and fast response times.

**temperature=0.1** for the LLM ensures deterministic, fact-grounded answers
rather than creative paraphrasing of policy language.

### Chunking Strategy

- **Splitter**: `RecursiveCharacterTextSplitter`
- **chunk_size**: 500 characters — large enough to capture a complete policy rule
  (e.g., an approval threshold table row + context), small enough that a single
  chunk stays focused and doesn't dilute retrieval relevance.
- **chunk_overlap**: 80 characters — preserves sentence continuity across chunk
  boundaries so no rule is truncated at a critical point.
- **Separators**: `["\n\n", "\n", ". ", " ", ""]` — tries to split at natural
  paragraph and sentence boundaries before resorting to word or character splits.

### Retrieval Approach

- **Model**: `text-embedding-3-small` (1536 dimensions) — Anthropic/OpenAI's
  recommended embedding model for semantic retrieval tasks.
- **Search type**: cosine similarity (FAISS default)
- **k = 4**: retrieves four chunks, providing enough context for multi-part
  policy questions without exceeding the LLM's useful context window.
- Source deduplication is applied so the same document is not cited twice.

### Limitations

1. **Static corpus** – Documents must be manually updated; no live sync.
2. **English only** – No multilingual support in current implementation.
3. **No conversation memory** – Each query is independent; follow-up questions
   do not retain prior context.
4. **No reranking** – A cross-encoder reranker (e.g., Cohere Rerank) would
   improve precision on ambiguous queries.

### Future Improvements

- Add BM25 hybrid search for better keyword-match recall on policy codes (e.g., "EXP-001").
- Integrate conversation history with `RunnableWithMessageHistory`.
- Add a Streamlit or FastAPI web UI.
- Implement automatic document sync from SharePoint / Confluence.
- Add evaluation harness using RAGAS metrics (faithfulness, answer relevancy).
