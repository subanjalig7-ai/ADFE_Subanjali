"""
Finance Policy Assistant – CLI entry point.

Usage:
    python -m finance_policy_assistant.app          # interactive mode
    python -m finance_policy_assistant.app --demo   # run 10 sample queries
    python -m finance_policy_assistant.app --rebuild # force index rebuild then interactive
"""

import argparse
import sys
import textwrap

from .chain import build_rag_chain, query
from .vectorstore import get_retriever

BANNER = """
╔══════════════════════════════════════════════════════════════╗
║          AI-POWERED FINANCE POLICY ASSISTANT                 ║
║     Powered by GPT-4o-mini  |  text-embedding-3-small        ║
║     Vector DB: FAISS  |  Orchestration: LangChain            ║
╚══════════════════════════════════════════════════════════════╝
"""

DEMO_QUERIES = [
    "What is the reimbursement limit for client travel meals?",
    "What approvals are required for a vendor payment of $15,000?",
    "Can international travel expenses be claimed? What are the rules?",
    "What documents are mandatory for a procurement request of $8,000?",
    "What is the mileage reimbursement rate for using a personal vehicle?",
    "When do I need to file a 1099-NEC form for a contractor?",
    "What is the hotel accommodation limit for domestic travel?",
    "How do I submit an expense report? What is the deadline?",
    "Are business class flights allowed? Under what conditions?",
    "What is the payment term for vendor invoices and how is payment made?",
]


def _separator(char: str = "─", width: int = 66) -> str:
    return char * width


def _print_result(question: str, result: dict, index: int = 0) -> None:
    label = f"Q{index}: " if index else ""
    print(f"\n{_separator()}")
    print(f"  {label}QUESTION: {question}")
    print(_separator())
    print("\n  ANSWER:")
    wrapped = textwrap.fill(result["answer"], width=64, initial_indent="  ", subsequent_indent="  ")
    print(wrapped)

    if result["sources"]:
        print(f"\n  SOURCES RETRIEVED ({len(result['sources'])} document(s)):")
        for src in result["sources"]:
            print(f"   • [{src['category']}]  {src['source']}")
            excerpt = textwrap.fill(
                src["excerpt"], width=60, initial_indent="     ", subsequent_indent="     "
            )
            print(excerpt)
    print()


def run_demo(chain) -> None:
    print("\n" + _separator("═"))
    print("  DEMO MODE – Running 10 sample finance policy queries")
    print(_separator("═"))
    for i, q in enumerate(DEMO_QUERIES, 1):
        print(f"\nProcessing query {i}/{len(DEMO_QUERIES)} …", end="\r")
        result = query(chain, q)
        _print_result(q, result, index=i)


def run_interactive(chain) -> None:
    print("\n" + _separator("═"))
    print("  INTERACTIVE MODE")
    print("  Type your finance policy question and press Enter.")
    print("  Type 'exit' or 'quit' to leave.")
    print(_separator("═"))

    while True:
        try:
            user_input = input("\n  Your question: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\n\nGoodbye!")
            break

        if not user_input:
            continue
        if user_input.lower() in {"exit", "quit", "q"}:
            print("\nThank you for using the Finance Policy Assistant. Goodbye!")
            break

        result = query(chain, user_input)
        _print_result(user_input, result)


def main() -> None:
    parser = argparse.ArgumentParser(description="Finance Policy Assistant")
    parser.add_argument("--demo", action="store_true", help="Run 10 pre-defined demo queries")
    parser.add_argument("--rebuild", action="store_true", help="Force rebuild of FAISS index")
    args = parser.parse_args()

    print(BANNER)
    print("Initializing … (this may take a moment on first run)\n")

    retriever = get_retriever(k=4, force_rebuild=args.rebuild)
    chain = build_rag_chain(retriever)
    print("Assistant ready!\n")

    if args.demo:
        run_demo(chain)
    else:
        run_interactive(chain)


if __name__ == "__main__":
    main()
