"""
Finance Policy Assistant
========================
An end-to-end RAG system that answers employee questions about internal finance
policies using semantic retrieval (FAISS + text-embedding-3-small) and grounded
response generation (GPT-4o-mini via LangChain).

Architecture:
  Documents (txt)
      ↓  TextLoader
  Raw Documents
      ↓  RecursiveCharacterTextSplitter (chunk_size=500, overlap=80)
  Chunks
      ↓  OpenAIEmbeddings (text-embedding-3-small)
  Vectors
      ↓  FAISS (persisted to faiss_index/)
  Retriever (top-k=4)
      ↓  create_retrieval_chain + create_stuff_documents_chain
  GPT-4o-mini
      ↓
  Grounded Answer + Source Citations
"""
