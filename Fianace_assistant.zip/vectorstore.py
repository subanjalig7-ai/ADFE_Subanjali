"""
FAISS vector store management.

Handles building the index from document chunks, persisting it to disk,
and exposing a retriever for the RAG chain.
"""

from pathlib import Path
from typing import List

from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_core.vectorstores import VectorStoreRetriever
from langchain_openai import OpenAIEmbeddings

from .config import setup_api_key
from .ingestion import load_and_chunk

INDEX_DIR = Path(__file__).parent / "faiss_index"

setup_api_key()

embeddings = OpenAIEmbeddings(model="text-embedding-3-small")


def build_vectorstore(chunks: List[Document], save_path: Path = INDEX_DIR) -> FAISS:
    """Embed chunks and build a FAISS index, then save to disk."""
    print("Building FAISS vector store …")
    store = FAISS.from_documents(chunks, embeddings)
    save_path.mkdir(parents=True, exist_ok=True)
    store.save_local(str(save_path))
    print(f"Vector store saved to {save_path}")
    return store


def load_vectorstore(save_path: Path = INDEX_DIR) -> FAISS:
    """Load an existing FAISS index from disk."""
    return FAISS.load_local(
        str(save_path),
        embeddings,
        allow_dangerous_deserialization=True,
    )


def get_vectorstore(force_rebuild: bool = False) -> FAISS:
    """Return a ready-to-use FAISS store, rebuilding only when necessary."""
    if not force_rebuild and INDEX_DIR.exists():
        print("Loading existing FAISS index …")
        return load_vectorstore()
    chunks = load_and_chunk()
    return build_vectorstore(chunks)


def get_retriever(k: int = 4, force_rebuild: bool = False) -> VectorStoreRetriever:
    """Return a retriever that fetches the top-k most relevant chunks."""
    store = get_vectorstore(force_rebuild=force_rebuild)
    return store.as_retriever(search_type="similarity", search_kwargs={"k": k})


if __name__ == "__main__":
    retriever = get_retriever()
    results = retriever.invoke("What is the reimbursement limit for meals?")
    for i, doc in enumerate(results, 1):
        print(f"\n--- Result {i} [{doc.metadata.get('source')}] ---")
        print(doc.page_content[:300])
