import os
from pathlib import Path


def _load_env_file():
    env_path = Path(__file__).parent / ".env"
    if env_path.exists():
        for line in env_path.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, _, value = line.partition("=")
                os.environ.setdefault(key.strip(), value.strip())


def setup_api_key():
    _load_env_file()
    if "OPENAI_API_KEY" not in os.environ:
        raise EnvironmentError(
            "OPENAI_API_KEY not found. Add it to finance_policy_assistant/.env"
        )
    print("API Key configured.")


if __name__ == "__main__":
    setup_api_key()
