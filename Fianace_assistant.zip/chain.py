"""
RAG chain using LangChain LCEL (compatible with LangChain 1.x).

Combines the FAISS retriever with GPT-4o-mini to produce grounded answers
that always reference the source policy document.
"""

from typing import Any, Dict, List

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda
from langchain_core.vectorstores import VectorStoreRetriever
from langchain_openai import ChatOpenAI

from .config import setup_api_key

setup_api_key()

llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.1)

_SYSTEM_PROMPT = """You are a Finance Policy Assistant for a large organization.
Your role is to help employees quickly find accurate answers from internal finance policy documents.

STRICT RULES:
1. Answer ONLY using the information in the provided context.
2. If the context does not contain sufficient information, respond with:
   "This information is not covered in the available policy documents. \
Please contact the Finance team at finance@company.com or extension 2200."
3. Quote specific policy numbers, limits, and deadlines wherever they appear in the context.
4. When you reference a fact, mention the source document name in parentheses.
5. Use bullet points for multi-step procedures or multiple items.
6. Keep answers concise and professional.

Context from Finance Policy Documents:
{context}"""

_prompt = ChatPromptTemplate.from_messages(
    [
        ("system", _SYSTEM_PROMPT),
        ("human", "{input}"),
    ]
)


def build_rag_chain(retriever: VectorStoreRetriever) -> Any:
    """Assemble the retrieval chain using LCEL."""
    def _run(inputs: Dict[str, Any]) -> Dict[str, Any]:
        question = inputs["input"]
        docs = retriever.invoke(question)
        context = "\n\n".join(doc.page_content for doc in docs)
        prompt_val = _prompt.invoke({"input": question, "context": context})
        answer = llm.invoke(prompt_val).content
        return {"answer": answer, "context": docs}

    return RunnableLambda(_run)


def query(chain: Any, question: str) -> Dict[str, Any]:
    """
    Run a question through the RAG chain.

    Returns a dict with:
      - answer: the generated response
      - sources: list of dicts with source file and excerpt
    """
    result = chain.invoke({"input": question})
    sources = _extract_sources(result.get("context", []))
    return {"answer": result["answer"], "sources": sources}


def _extract_sources(docs: List[Any]) -> List[Dict[str, str]]:
    """Deduplicate and format retrieved source chunks for display."""
    seen: set = set()
    sources: List[Dict[str, str]] = []
    for doc in docs:
        src = doc.metadata.get("source", "Unknown")
        if src not in seen:
            seen.add(src)
            sources.append(
                {
                    "source": src,
                    "category": doc.metadata.get("category", "Unknown"),
                    "excerpt": doc.page_content[:250].strip() + " …",
                }
            )
    return sources
