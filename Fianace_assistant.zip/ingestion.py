"""
Document ingestion pipeline.

Loads finance policy documents from the documents/ directory,
applies recursive text splitting, and attaches source metadata.
"""

from pathlib import Path
from typing import List

from langchain_community.document_loaders import TextLoader
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter

DOCS_DIR = Path(__file__).parent / "documents"

# Chunk size chosen to keep each chunk under the typical context limit while
# retaining enough surrounding text for semantic coherence.
CHUNK_SIZE = 500
CHUNK_OVERLAP = 80


def load_documents(docs_dir: Path = DOCS_DIR) -> List[Document]:
    """Load all .txt policy files and tag each doc with source metadata."""
    documents: List[Document] = []
    for filepath in sorted(docs_dir.glob("*.txt")):
        loader = TextLoader(str(filepath), encoding="utf-8")
        docs = loader.load()
        for doc in docs:
            doc.metadata["source"] = filepath.name
            doc.metadata["category"] = filepath.stem.replace("_", " ").title()
        documents.extend(docs)
    print(f"Loaded {len(documents)} document(s) from {docs_dir}")
    return documents


def chunk_documents(documents: List[Document]) -> List[Document]:
    """Split documents into smaller overlapping chunks for retrieval."""
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        separators=["\n\n", "\n", ". ", " ", ""],
    )
    chunks = splitter.split_documents(documents)
    print(f"Created {len(chunks)} chunks from {len(documents)} document(s)")
    return chunks


def load_and_chunk(docs_dir: Path = DOCS_DIR) -> List[Document]:
    """Convenience wrapper: load documents then chunk them."""
    documents = load_documents(docs_dir)
    return chunk_documents(documents)


if __name__ == "__main__":
    chunks = load_and_chunk()
    print(f"\nSample chunk:\n{chunks[0].page_content}")
    print(f"Metadata: {chunks[0].metadata}")
