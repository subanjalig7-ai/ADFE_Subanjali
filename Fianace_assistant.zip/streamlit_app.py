"""
Finance Policy Assistant – Streamlit web UI.
Run with: streamlit run finance_policy_assistant/streamlit_app.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import streamlit as st
from finance_policy_assistant.chain import build_rag_chain, query
from finance_policy_assistant.vectorstore import get_retriever

st.set_page_config(
    page_title="Finance Policy Assistant",
    page_icon="💼",
    layout="centered",
)

st.title("💼 AI-Powered Finance Policy Assistant")
st.caption("Powered by GPT-4o-mini · FAISS · LangChain")
st.divider()


@st.cache_resource(show_spinner="Loading policy documents and building index…")
def load_chain():
    retriever = get_retriever(k=4)
    return build_rag_chain(retriever)


chain = load_chain()

if "messages" not in st.session_state:
    st.session_state.messages = []

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg.get("sources"):
            with st.expander(f"Sources ({len(msg['sources'])} document(s))"):
                for src in msg["sources"]:
                    st.markdown(f"**[{src['category']}]** `{src['source']}`")
                    st.caption(src["excerpt"])

if prompt := st.chat_input("Ask a finance policy question…"):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        with st.spinner("Searching policy documents…"):
            result = query(chain, prompt)

        st.markdown(result["answer"])

        if result["sources"]:
            with st.expander(f"Sources ({len(result['sources'])} document(s))"):
                for src in result["sources"]:
                    st.markdown(f"**[{src['category']}]** `{src['source']}`")
                    st.caption(src["excerpt"])

    st.session_state.messages.append({
        "role": "assistant",
        "content": result["answer"],
        "sources": result["sources"],
    })
